#!/bin/bash
# =====================================================================
# chui_env.sh: shared settings for every Chui script (v7).
#
#   source slurm/chui_env.sh
#
# Sourced by setup_env.sh and every *.sbatch file, and by you on the login
# node before running anything by hand. Edit the lines marked TODO(Chui).
# Values from the KENET wiki (training.kenet.or.ke, Nov 2026) are marked
# "wiki"; everything else is a guess to check with `module avail`,
# `sinfo` and `df -h ~ ~/localscratch`.
# =====================================================================

# --- Where things live ------------------------------------------------
# The code (unzipped novel_continual_learning_v7).
export CODE_DIR="${CODE_DIR:-$HOME/novel_continual_learning_v7}"

# Data, logs, finished runs and results. The wiki uses ~/localscratch as
# "your scratch directory" for jobs. TODO(Chui): confirm it is shared
# between the login and GPU nodes, is not purged, and has room (~10 GB
# incl. the model cache). If it is purged, copy results out regularly.
export EXPERIMENT_ROOT="${EXPERIMENT_ROOT:-$HOME/localscratch/thesis_v7}"

# Hugging Face cache (the ~3 GB Qwen2.5-1.5B download). Kept under the
# storage root so home quota is not used.
export HF_HOME="${HF_HOME:-$EXPERIMENT_ROOT/hf_cache}"

# The Python environment created by setup_env.sh.
export ENV_DIR="${ENV_DIR:-$HOME/envs/ncl_v7}"
export PYTHON_VERSION="${PYTHON_VERSION:-3.11}"

# --- Conda (only needed by setup_env.sh) ----------------------------------
# setup_env.sh needs *a* conda to create the env; it tries, in order:
#   1. conda already on PATH (e.g. inside JupyterLab on Chui)
#   2. module load $NCL_CONDA_MODULE. wiki name; it exists on the GPU nodes
#      but NOT on the login node (controller-icolo), so this usually fails there
#   3. $NCL_CONDA_BASE, the cluster's shared conda (/opt/ohpc/pub/conda/instdir,
#      per the wiki), ~/miniforge3, ~/miniconda3
#   4. installs Miniforge into ~/miniforge3 (needs internet; the login node has it)
# (Named NCL_CONDA_MODULE, not CONDA_MODULE, so it cannot clash with a
# variable the module system sets or unsets.)
export NCL_CONDA_MODULE="${NCL_CONDA_MODULE:-applications/gpu/python/conda-25.1.1-python-3.9.21}"

find_conda() {
    command -v conda >/dev/null 2>&1 && return 0
    if [ -n "$NCL_CONDA_MODULE" ] && command -v module >/dev/null 2>&1 \
       && module load "$NCL_CONDA_MODULE" >/dev/null 2>&1 && command -v conda >/dev/null 2>&1; then
        return 0
    fi
    local base
    for base in "${NCL_CONDA_BASE:-}" /opt/ohpc/pub/conda/instdir "$HOME/miniforge3" "$HOME/miniconda3"; do
        if [ -n "$base" ] && [ -f "$base/etc/profile.d/conda.sh" ]; then
            source "$base/etc/profile.d/conda.sh"
            command -v conda >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}

# --- The experiment's Python ---------------------------------------------
# The env is self-contained (its own python and CUDA-bundled torch wheels), so
# jobs and the notebook only put its bin/ first on PATH. No module or conda is
# needed at run time, which avoids module names that differ between nodes.
load_python_env() {
    if [ ! -x "$ENV_DIR/bin/python" ]; then
        echo "No Python env at $ENV_DIR. Run 'bash slurm/setup_env.sh' on the login node first."
        return 1
    fi
    export PATH="$ENV_DIR/bin:$PATH"
}

# True if this node can reach PyPI and Hugging Face. Chui's compute nodes
# (including JupyterLab sessions) cannot; the login node normally can.
has_internet() {
    getent hosts pypi.org >/dev/null 2>&1 && getent hosts huggingface.co >/dev/null 2>&1
}

# --- Runtime settings for jobs ------------------------------------------
# Compute nodes may have no internet; the model is pre-downloaded by
# setup_env.sh, so jobs never contact the Hugging Face Hub.
offline_mode() {
    export HF_HUB_OFFLINE=1
    export TRANSFORMERS_OFFLINE=1
    export HF_DATASETS_OFFLINE=1
    export TOKENIZERS_PARALLELISM=false
    export PYTHONUNBUFFERED=1                       # live output in slurm-*.out
    export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-4}"
    export MKL_NUM_THREADS="$OMP_NUM_THREADS"
}

mkdir -p "$EXPERIMENT_ROOT" "$HF_HOME" 2>/dev/null || true
