#!/bin/bash
# =====================================================================
# aggregate.sbatch: mean ± std over seeds from every finished run (v7).
# submit_all.sh submits it to start after the array ends. Run it again any
# time (it trains nothing):
#   sbatch slurm/aggregate.sbatch
# or on the login node:
#   source slurm/chui_env.sh && load_python_env && python run_experiment.py --aggregate-only --seeds 42 43 44 45 46
# =====================================================================
#SBATCH --job-name=ncl-aggregate
#SBATCH --partition=normal          # wiki: CPU partition
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G                    # TODO(Chui): remove if the partition does not allow --mem
#SBATCH --time=00:20:00
#SBATCH --output=logs/%x-%j.out
##SBATCH --qos=cpu_only             # TODO(Chui): uncomment if CPU jobs need the cpu_only QOS
set -eo pipefail   # no -u: Lmod and conda scripts read unset variables
cd "${SLURM_SUBMIT_DIR:-.}"
source slurm/chui_env.sh
load_python_env
offline_mode

# shellcheck disable=SC2086
python run_experiment.py --aggregate-only --seeds ${SEEDS:-42 43 44 45 46} \
    --datasets "${DATASETS:-synthetic,sheng}" ${EXTRA_ARGS:-}
