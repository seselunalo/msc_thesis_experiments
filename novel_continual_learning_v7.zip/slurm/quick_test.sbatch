#!/bin/bash
# =====================================================================
# quick_test.sbatch: plumbing check on one GPU (v7).
#   sbatch slurm/quick_test.sbatch
# 5 synthetic eras x 200 and 50 Sheng posts per era, all seven models,
# seed 42. Uses its own storage subfolder ($EXPERIMENT_ROOT/quick_test) so
# its small synthetic stream never replaces the full one.
# =====================================================================
#SBATCH --job-name=ncl-quick
#SBATCH --partition=gpu1            # wiki: GPU partition, 24 h limit
#SBATCH --gres=gpu:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4           # TODO(Chui): check cores per GPU on gpu1 (`scontrol show node`)
#SBATCH --mem=48G                   # TODO(Chui): remove if the partition does not allow --mem
#SBATCH --time=02:00:00
#SBATCH --output=logs/%x-%j.out
##SBATCH --qos=gpu_only             # TODO(Chui): uncomment if your account needs the gpu_only QOS
##SBATCH --account=YOUR_ACCOUNT     # TODO(Chui): only if KENET gave you a project account
set -eo pipefail   # no -u: Lmod and conda scripts read unset variables
cd "${SLURM_SUBMIT_DIR:-.}"
source slurm/chui_env.sh
load_python_env
offline_mode

QUICK_ROOT="$EXPERIMENT_ROOT/quick_test"
mkdir -p "$QUICK_ROOT/novel_continual_learning/data"
rsync -a "$EXPERIMENT_ROOT/novel_continual_learning/data/sheng" "$QUICK_ROOT/novel_continual_learning/data/"

echo "Job $SLURM_JOB_ID on $(hostname), partition $SLURM_JOB_PARTITION"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv
python -c "import torch; assert torch.cuda.is_available(), 'PyTorch cannot see the GPU'; print('GPU:', torch.cuda.get_device_name(0))"

python run_experiment.py --storage-root "$QUICK_ROOT" --quick --resume
