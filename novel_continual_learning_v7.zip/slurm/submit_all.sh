#!/bin/bash
# =====================================================================
# submit_all.sh: submit the seed array plus the summary job that runs after it.
#
#   bash slurm/submit_all.sh                                   # 5 seeds x (core, variants) = 10 tasks
#   SEEDS="42 43 44" bash slurm/submit_all.sh                  # fewer seeds
#   MODEL_GROUPS="all" bash slurm/submit_all.sh                      # one task per seed, all 7 models
#   MODEL_GROUPS="static naive periodic novel dora loraplus olora" bash slurm/submit_all.sh   # one task per model
#   DATASETS=sheng MODEL_GROUPS=variants bash slurm/submit_all.sh    # variants on Sheng only
#   MAX_PARALLEL=1 bash slurm/submit_all.sh                    # one GPU at a time
#   EXTRA_ARGS="--ft-mode lora" bash slurm/submit_all.sh       # passed to run_experiment.py
#
# Re-running the same command after a time-out or failure continues where it
# stopped: finished runs are skipped.
# =====================================================================
set -eo pipefail   # no -u: Lmod and conda scripts read unset variables
cd "$(dirname "$0")/.."
mkdir -p logs

export SEEDS="${SEEDS:-42 43 44 45 46}"
export MODEL_GROUPS="${MODEL_GROUPS:-core variants}"
export DATASETS="${DATASETS:-synthetic,sheng}"
export EXTRA_ARGS="${EXTRA_ARGS:-}"
# wiki: the gpu_only QOS allows at most 2 GPUs (MaxTRES gres/gpu=2).
MAX_PARALLEL="${MAX_PARALLEL:-2}"

read -r -a S <<< "$SEEDS"
read -r -a G <<< "$MODEL_GROUPS"
N=$(( ${#S[@]} * ${#G[@]} ))
echo "Submitting $N tasks: seeds [${SEEDS}] x groups [${MODEL_GROUPS}], datasets ${DATASETS}, at most $MAX_PARALLEL at once"

ARRAY_ID=$(sbatch --parsable --array="0-$((N - 1))%${MAX_PARALLEL}" \
           --export=ALL,SEEDS,MODEL_GROUPS,DATASETS,EXTRA_ARGS slurm/run_seeds.sbatch)
echo "Array job:     $ARRAY_ID   (logs/ncl-v7-${ARRAY_ID}_<task>.out)"

# afterany: summarise even if some tasks failed or timed out; the summary
# lists the runs that are still missing.
AGG_ID=$(sbatch --parsable --dependency="afterany:${ARRAY_ID}" \
         --export=ALL,SEEDS,DATASETS,EXTRA_ARGS slurm/aggregate.sbatch)
echo "Summary job:   $AGG_ID   (starts when the array ends)"
echo "Watch with:    squeue -u ${USER:-$(whoami)}"
