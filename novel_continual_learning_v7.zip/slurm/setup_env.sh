#!/bin/bash
# =====================================================================
# setup_env.sh: one-time setup on the Chui LOGIN node (needs internet).
#
#   cd ~/novel_continual_learning_v7
#   bash slurm/setup_env.sh                 # everything
#   bash slurm/setup_env.sh --skip-env      # keep the env, redo data + model
#
# 1. creates a conda env ($ENV_DIR, Python $PYTHON_VERSION) and installs
#    requirements.txt (removing torchao, as on Colab);
# 2. downloads Qwen2.5-1.5B into $HF_HOME for offline jobs;
# 3. exports the Sheng eras from $SHENG_CSV (default
#    $EXPERIMENT_ROOT/sheng_clean.csv);
# 4. generates the full synthetic stream once, so the
#    array tasks never generate it at the same time;
# 5. writes pip freeze + versions to $EXPERIMENT_ROOT/environment.txt
#    (cite these versions in the thesis).
# =====================================================================
set -eo pipefail   # no -u: Lmod and conda scripts read unset variables
cd "$(dirname "$0")/.."
source slurm/chui_env.sh
mkdir -p logs        # the sbatch files write their output here; SLURM does not create it
echo "Code:          $CODE_DIR ($(pwd))"
echo "Storage root:  $EXPERIMENT_ROOT"
echo "HF cache:      $HF_HOME"
echo "Env:           $ENV_DIR"
echo "Node:          $(hostname)"

# Setup downloads packages (PyPI, conda) and the model (Hugging Face). Chui's
# compute nodes, including JupyterLab sessions, have no internet, so stop
# early with instructions instead of retrying for minutes.
if [ "${NCL_SKIP_NET_CHECK:-0}" != 1 ] && ! has_internet; then
    cat <<MSG

!! This node ($(hostname)) cannot reach pypi.org / huggingface.co, so setup
!! cannot download anything here. Run it once on the LOGIN node instead:
!!   OnDemand -> Clusters -> Shell Access (or ssh -p PORT you@HOSTNAME), then
!!     cd "$(pwd)" && bash slurm/setup_env.sh
!! Then go back to the notebook and continue with section 5 (the jobs and the
!! notebook use the env and model cache it creates; they need no internet).
!! (Set NCL_SKIP_NET_CHECK=1 to try anyway, e.g. behind a proxy.)
MSG
    exit 3
fi

if [ "${1:-}" != "--skip-env" ]; then
    if ! find_conda; then
        echo "No conda found (module $NCL_CONDA_MODULE is not available on $(hostname))."
        echo "Installing Miniforge (conda from conda-forge) into $HOME/miniforge3 ..."
        curl -fsSL -o "$HOME/miniforge_installer.sh" \
            "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh"
        bash "$HOME/miniforge_installer.sh" -b -p "$HOME/miniforge3"
        rm -f "$HOME/miniforge_installer.sh"
        source "$HOME/miniforge3/etc/profile.d/conda.sh"
    fi
    echo "conda: $(command -v conda) ($(conda --version))"
    if [ -d "$ENV_DIR" ] && [ ! -f "$ENV_DIR/.ncl_v7_ready" ]; then
        echo "Removing an incomplete env from an earlier attempt: $ENV_DIR"
        rm -rf "$ENV_DIR"
    fi
    if [ ! -d "$ENV_DIR" ]; then
        mkdir -p "$(dirname "$ENV_DIR")"
        # The module's conda uses the 'defaults' channel; Miniforge uses
        # conda-forge. Either gives a self-contained Python $PYTHON_VERSION.
        conda create -y -p "$ENV_DIR" "python=$PYTHON_VERSION" pip
    fi
    load_python_env
    echo "python: $(command -v python) ($(python --version 2>&1))"
    python -m pip install --upgrade pip
    # PyPI's Linux torch wheels bundle CUDA 12 (they need an NVIDIA driver
    # >= 525 on the GPU nodes; check `nvidia-smi` in a GPU job). To pick a
    # specific CUDA build, set TORCH_INDEX_URL, e.g.
    #   TORCH_INDEX_URL=https://download.pytorch.org/whl/cu121 bash slurm/setup_env.sh
    if [ -n "${TORCH_INDEX_URL:-}" ]; then
        python -m pip install torch --index-url "$TORCH_INDEX_URL"
    fi
    python -m pip install -r requirements.txt
    # Same as the Colab notebooks: an old torchao makes peft's get_peft_model
    # crash, and LoRA does not need it.
    python -m pip uninstall -y torchao 2>/dev/null || true
    python -c "import torch, transformers, peft, sklearn, psutil" && touch "$ENV_DIR/.ncl_v7_ready"
    # Optional: makes this env selectable as a Jupyter kernel ("Python (ncl_v7)")
    # in JupyterLab on Open OnDemand. The notebook does not need it.
    { python -m pip install -q ipykernel && \
      python -m ipykernel install --user --name ncl_v7 --display-name "Python (ncl_v7)"; } \
      || echo "(ipykernel not installed; the notebook still works)"
else
    load_python_env
fi

python - <<'PY'
import torch, transformers, peft, sys
print(f"python {sys.version.split()[0]} | torch {torch.__version__} (CUDA {torch.version.cuda}) | "
      f"transformers {transformers.__version__} | peft {peft.__version__}")
PY

echo "== Downloading the base model to $HF_HOME"
python download_model.py

echo "== Exporting the Sheng eras"
SHENG_CSV="${SHENG_CSV:-$EXPERIMENT_ROOT/sheng_clean.csv}"
if [ -f "$SHENG_CSV" ]; then
    python -m data.export_sheng --csv "$SHENG_CSV"
else
    echo "!! $SHENG_CSV not found. Upload it (README_v7, step 2), then run:"
    echo "   bash slurm/setup_env.sh --skip-env"
    exit 1
fi

echo "== Preparing the synthetic stream (20 eras x 1,000)"
python run_experiment.py --prepare-data

{
  echo "# Environment for novel_continual_learning v7 on Chui, $(date -Iseconds)"
  python -c "import platform,torch,transformers,peft;print('python',platform.python_version());print('torch',torch.__version__,'cuda',torch.version.cuda);print('transformers',transformers.__version__);print('peft',peft.__version__)"
  python -m pip freeze
} > "$EXPERIMENT_ROOT/environment.txt"
echo "== Done. Versions in $EXPERIMENT_ROOT/environment.txt"
echo "   Next: sbatch slurm/quick_test.sbatch"
