#!/bin/bash
# =====================================================================
# run_seeds.sbatch: the full experiment as a SLURM job array (v7).
#
# Submit it with slurm/submit_all.sh, which sets --array to the number of
# tasks. Each array task runs ONE (seed, model group) pair on one GPU:
#
#   SEEDS="42 43 44 45 46"  MODEL_GROUPS="core variants"   ->  10 tasks
#   task i  ->  seed = SEEDS[i / n_groups], models = MODEL_GROUPS[i % n_groups]
#
# Every finished (seed, dataset, model) run is saved at once as its own file,
# so a task that hits the 24 h limit loses only the run in progress.
# Re-submitting the same command continues (--resume skips finished runs).
#
# Overrides, all optional (pass with --export or set them before submit_all.sh):
#   SEEDS, MODEL_GROUPS, DATASETS (default "synthetic,sheng"), EXTRA_ARGS (e.g. "--ft-mode full")
# =====================================================================
#SBATCH --job-name=ncl-v7
#SBATCH --partition=gpu1            # wiki: GPU partition, 24 h per job
#SBATCH --gres=gpu:1
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4           # TODO(Chui): check cores per GPU on gpu1
#SBATCH --mem=64G                   # TODO(Chui): remove if the partition does not allow --mem
#SBATCH --time=24:00:00             # wiki: 24 h maximum on gpu1
#SBATCH --output=logs/%x-%A_%a.out
##SBATCH --qos=gpu_only             # TODO(Chui): uncomment if your account needs the gpu_only QOS
##SBATCH --account=YOUR_ACCOUNT     # TODO(Chui): only if KENET gave you a project account
set -eo pipefail   # no -u: Lmod and conda scripts read unset variables
cd "${SLURM_SUBMIT_DIR:-.}"
source slurm/chui_env.sh
load_python_env
offline_mode

read -r -a SEED_LIST <<< "${SEEDS:-42 43 44 45 46}"
read -r -a GROUP_LIST <<< "${MODEL_GROUPS:-core variants}"
TASK=${SLURM_ARRAY_TASK_ID:-0}
NG=${#GROUP_LIST[@]}
if (( TASK >= ${#SEED_LIST[@]} * NG )); then
    echo "Array index $TASK is out of range for ${#SEED_LIST[@]} seeds x $NG groups"; exit 2
fi
SEED=${SEED_LIST[$((TASK / NG))]}
MODELS=${GROUP_LIST[$((TASK % NG))]}

echo "Task $TASK of array $SLURM_ARRAY_JOB_ID on $(hostname): seed $SEED, models $MODELS"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv

# shellcheck disable=SC2086  # EXTRA_ARGS is meant to split into words
python run_experiment.py --seeds "$SEED" --models "$MODELS" \
    --datasets "${DATASETS:-synthetic,sheng}" --resume ${EXTRA_ARGS:-}
