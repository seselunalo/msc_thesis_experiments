#!/bin/bash
# =====================================================================
# submit_replay_study.sh (v7.2): the supervisor's three replay experiments,
# plus the LoRA+ re-run, at the 20 eras of the main results. Run on the login
# node after `python run_experiment.py --prepare-data --eras 20`:
#
#   bash slurm/submit_replay_study.sh              # everything below
#   PARTS="design" bash slurm/submit_replay_study.sh       # only part 1
#   SEEDS="42 43 44" bash slurm/submit_replay_study.sh     # fewer seeds
#
#   1. design    Update method x replay (buffer 1000), 2 x 3 arms:
#                LoRA (Novel): replay / no replay / no replay at equal exposure
#                Full FT     : replay / no replay / no replay at equal exposure
#   2. capacity  Buffer 64, 256 and the complete history ('all') for Novel and
#                Naive FT + replay; 1000 comes from part 1. Replay ratio fixed
#                (16 replayed per 16 new samples).
#   3. loraplus  LoRA+ with the v7.1 learning-rate fix.
#
# Every job runs with --ft-mode full, so the "Naive FT" arms are full
# fine-tuning whatever GPU they land on (the L40S has room). All arrays are
# submitted at once; the gpu_only QOS runs at most 2 GPUs, the rest wait in
# the queue. Re-running this script after a time-out skips finished runs.
# When everything has finished:
#   python tools/replay_study_report.py --eras 20
# =====================================================================
set -eo pipefail
cd "$(dirname "$0")/.."
export SEEDS="${SEEDS:-42 43 44 45 46}"
PARTS="${PARTS:-design capacity loraplus}"
ERAS="${ERAS:-20}"

for part in $PARTS; do
  case "$part" in
    design)
      echo "== 1. Update method x replay (6 arms, buffer 1000)"
      MODEL_GROUPS="novel,novel_noreplay,novel_matched naive,naive_replay,naive_matched" \
      EXTRA_ARGS="--eras $ERAS --ft-mode full" bash slurm/submit_all.sh ;;
    capacity)
      for k in 64 256 all; do
        echo "== 2. Buffer capacity $k"
        MODEL_GROUPS="novel naive_replay" \
        EXTRA_ARGS="--eras $ERAS --ft-mode full --buffer-capacity $k" bash slurm/submit_all.sh
      done ;;
    loraplus)
      echo "== 3. LoRA+ re-run"
      MODEL_GROUPS="loraplus" EXTRA_ARGS="--eras $ERAS --ft-mode full" bash slurm/submit_all.sh ;;
    *) echo "unknown part '$part' (design, capacity, loraplus)"; exit 2 ;;
  esac
done
echo
echo "When all jobs are done:  python tools/replay_study_report.py --eras $ERAS"
