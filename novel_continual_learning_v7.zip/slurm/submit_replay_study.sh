#!/bin/bash
# =====================================================================
# submit_replay_study.sh (v7.2): every experiment still pending after the
# main 10-era run (job 63010), in one go. Run on the login node:
#
#   source slurm/chui_env.sh && load_python_env
#   python run_experiment.py --prepare-data --eras 10      # once; skip if done
#   bash slurm/submit_replay_study.sh                      # design + capacity + rank
#
#   PARTS="design" bash slurm/submit_replay_study.sh       # one part only
#   SEEDS="42 43 44" bash slurm/submit_replay_study.sh     # fewer seeds
#   ERAS=20 bash slurm/submit_replay_study.sh              # 20 eras (prepare --eras 20 first)
#
#   1. design    Update method x replay (buffer 1000), 2 x 3 arms:
#                LoRA (Novel): replay / no replay / no replay at equal exposure
#                Full FT     : replay / no replay / no replay at equal exposure
#   2. capacity  Buffer 64, 256 and the complete history ('all') for Novel and
#                Naive FT + replay; 1000 comes from part 1. Replay ratio fixed
#                (16 replayed per 16 new samples).
#   3. rank      Novel with LoRA rank 4 and 16 (alpha = 2r); r = 8 comes from
#                part 1, so all three ranks share seeds and settings.
#   loraplus     (not in the default) LoRA+ alone; already done in job 63010.
#
# Every job uses --ft-mode full, so the "Naive FT" arms are full fine-tuning
# on any GPU. All arrays are submitted at once; the gpu_only QOS runs at most
# 2 GPUs and the rest wait. Re-running this script skips finished runs.
# When everything has finished:
#   python tools/replay_study_report.py
# =====================================================================
set -eo pipefail
cd "$(dirname "$0")/.."
export SEEDS="${SEEDS:-42 43 44 45 46}"
PARTS="${PARTS:-design capacity rank}"
ERAS="${ERAS:-10}"
COMMON="--eras $ERAS --ft-mode full"

for part in $PARTS; do
  case "$part" in
    design)
      echo "== 1. Update method x replay (6 arms, buffer 1000)"
      MODEL_GROUPS="novel,novel_noreplay,novel_matched naive,naive_replay,naive_matched" \
      EXTRA_ARGS="$COMMON" bash slurm/submit_all.sh ;;
    capacity)
      for k in 64 256 all; do
        echo "== 2. Buffer capacity $k"
        MODEL_GROUPS="novel naive_replay" \
        EXTRA_ARGS="$COMMON --buffer-capacity $k" bash slurm/submit_all.sh
      done ;;
    rank)
      for r in 4 16; do
        echo "== 3. LoRA rank $r"
        MODEL_GROUPS="novel" EXTRA_ARGS="$COMMON --lora-r $r" bash slurm/submit_all.sh
      done ;;
    loraplus)
      echo "== LoRA+ only"
      MODEL_GROUPS="loraplus" EXTRA_ARGS="$COMMON" bash slurm/submit_all.sh ;;
    *) echo "unknown part '$part' (design, capacity, rank, loraplus)"; exit 2 ;;
  esac
done
echo
echo "When all jobs are done:  python tools/replay_study_report.py --eras $ERAS"
