"""
Continual Learning Evaluator (v5).

Builds the accuracy matrix R, where R[r, j] is the accuracy on era j's
held-out test set after training on the first r eras (r = 0 is before any
training). The metrics follow Lopez-Paz & Ranzato (2017) and Chaudhry et al. (2018).
With T eras indexed j = 0..T-1:

    AA  = mean_j R[T, j]                                  final average accuracy
    BWT = mean_{j<T-1} (R[T, j] - R[j+1, j])              backward transfer
    AF  = mean_{j<T-1} (max_{j+1<=r<=T-1} R[r, j] - R[T, j])   average forgetting
    FWT = mean_{j>=1} (R[j, j] - R[0, j])                 forward transfer: accuracy
          on an era *before* training on it, relative to the untrained model
    LA  = mean_j R[j+1, j]                                learning accuracy (just after training)

The same matrix is kept for macro-F1, and Macro-F1 in the summary is the
final average over eras, mean_j F1[T, j].

v4 differences fixed here: v4 reported FWT as the training accuracy of the last
5 batches, and it never evaluated an era before training on it.
"""

import time
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

from config.config import Config

Batch = Tuple[List[str], List[int]]


class ContinualLearningEvaluator:
    def __init__(self, model, model_name: str = "Model"):
        self.model = model
        self.model_name = model_name
        self.history = {"train_loss": [], "time_per_step": [], "eval_time_per_step": []}

    def _eval_eras(self, test_batches: List[Batch], upto: int):
        acc, f1 = {}, {}
        for j in range(min(upto, len(test_batches))):
            m = self.model.evaluate(*test_batches[j])
            acc[j], f1[j] = m["accuracy"], m["macro_f1"]
        return acc, f1

    def evaluate_continually(
        self,
        stream_batches: List[Batch],
        test_batches: List[Batch],
        eval_every: int = Config.EVAL_EVERY,
        verbose: bool = True,
    ) -> Dict:
        T = len(stream_batches)
        assert len(test_batches) == T, "need one held-out test set per era"
        R = np.full((T + 1, T), np.nan)
        F = np.full((T + 1, T), np.nan)
        peak = 0.0

        # Row 0: untrained model on every era (reference for FWT).
        acc, f1 = self._eval_eras(test_batches, T)
        for j in acc:
            R[0, j], F[0, j] = acc[j], f1[j]

        for t in range(T):
            loss, step_time = self.model.train_step(*stream_batches[t])
            self.history["train_loss"].append(loss)
            self.history["time_per_step"].append(step_time)
            if torch.cuda.is_available():
                peak = max(peak, torch.cuda.max_memory_allocated() / 1024 ** 2)

            # Row t+1: eras seen so far, plus the next era (needed for FWT).
            e0 = time.time()
            acc, f1 = self._eval_eras(test_batches, t + 2)
            for j in acc:
                R[t + 1, j], F[t + 1, j] = acc[j], f1[j]
            self.history["eval_time_per_step"].append(time.time() - e0)

            if verbose and (t + 1) % eval_every == 0:
                seen = np.nanmean(R[t + 1, :t + 1])
                loss_s = f"loss={loss:.4f}" if loss is not None else "loss=n/a (no update this era)"
                print(f"[{self.model_name}] era {t + 1}/{T}: {loss_s} "
                      f"acc(era {t + 1})={R[t + 1, t]:.4f} mean acc(seen)={seen:.4f}")

        results = self._compute_metrics(R, F)
        results["peak_memory_mb"] = peak
        results["train_time_seconds"] = float(sum(self.history["time_per_step"]))
        results["history"] = self.history
        results["acc_matrix"] = R.tolist()
        results["f1_matrix"] = F.tolist()
        # v4-compatible view: accuracy of each era after each later step.
        results["era_histories"] = {j: R[j + 1:, j].tolist() for j in range(T)}
        return results

    @staticmethod
    def _compute_metrics(R: np.ndarray, F: np.ndarray) -> Dict[str, float]:
        T = R.shape[1]
        final = R[T]
        out = {"AA": float(np.mean(final)), "Macro-F1": float(np.mean(F[T])),
               "LA": float(np.mean([R[j + 1, j] for j in range(T)]))}
        if T > 1:
            out["BWT"] = float(np.mean([R[T, j] - R[j + 1, j] for j in range(T - 1)]))
            out["AF"] = float(np.mean([np.max(R[j + 1:T, j]) - R[T, j] for j in range(T - 1)]))
            out["FWT"] = float(np.mean([R[j, j] - R[0, j] for j in range(1, T)]))
        else:
            out["BWT"] = out["AF"] = out["FWT"] = 0.0
        return out

    def print_summary(self, results: Dict):
        print("\n" + "=" * 70)
        print(f"EVALUATION SUMMARY: {self.model_name}")
        print("=" * 70)
        for k in ["AA", "AF", "FWT", "BWT", "LA", "Macro-F1"]:
            print(f"{k:<10} {results.get(k, 0.0):.4f}")
        print(f"Peak GPU memory: {results.get('peak_memory_mb', 0.0):.1f} MB")
        print("=" * 70)
