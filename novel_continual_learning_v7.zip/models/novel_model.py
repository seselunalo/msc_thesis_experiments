"""
Novel Continual Learning Model: state S_t = (W, Y_t, Z_t)
    W   : frozen base model (shared via BaseContinualModel)
    Y_t : LoRA adapters plus classification head (trainable)
    Z_t : reservoir replay buffer

v5: each era is trained for EPOCHS_PER_ERA epochs in mini-batches, and every
mini-batch of new data is joined by REPLAY_BATCH_SIZE samples from Z_t. The
buffer is updated after the era, so replay only holds past eras.
"""

import os
import time
from typing import List, Tuple

import torch
from peft import LoraConfig, PeftModel, TaskType, get_peft_model

from config.config import Config
from .base_model import BaseContinualModel
from .reservoir_buffer import ReservoirBuffer


class NovelContinualLearningModel(BaseContinualModel):
    def __init__(
        self,
        lora_r: int = Config.LORA_R,
        lora_alpha: int = Config.LORA_ALPHA,
        lora_dropout: float = Config.LORA_DROPOUT,
        lora_target_modules: List[str] = Config.LORA_TARGET_MODULES,
        buffer_capacity: int = Config.BUFFER_CAPACITY,
        replay_batch_size: int = Config.REPLAY_BATCH_SIZE,
        learning_rate: float = Config.LEARNING_RATE,
        weight_decay: float = Config.WEIGHT_DECAY,
        epochs_per_era: int = Config.EPOCHS_PER_ERA,
        device: str = Config.DEVICE,
        seed: int = Config.RANDOM_SEED,
    ):
        super().__init__(device=device, seed=seed)
        lora_config = LoraConfig(
            task_type=TaskType.SEQ_CLS,      # also makes the classification head trainable
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=lora_target_modules,
            bias="none",
        )
        self.model = get_peft_model(self.base_model, lora_config).to(device)
        self.memory = ReservoirBuffer(capacity=buffer_capacity, seed=seed)
        self.replay_batch_size = replay_batch_size
        self.epochs_per_era = epochs_per_era
        self.optimizer = torch.optim.AdamW(
            [p for p in self.model.parameters() if p.requires_grad],
            lr=learning_rate, weight_decay=weight_decay)
        self.current_step = 0
        trainable = self.get_trainable_parameters()
        print(f"Novel model: {trainable:,} trainable parameters "
              f"({100 * trainable / self.get_total_parameters():.2f}%)")

    def train_step(self, texts: List[str], labels: List[int]) -> Tuple[float, float]:
        start = time.time()
        loss = self._fit(self.model, self.optimizer, texts, labels, self.epochs_per_era,
                         replay=self.memory, replay_batch_size=self.replay_batch_size)
        self.memory.update(list(zip(texts, labels)))
        self.current_step += 1
        return loss, time.time() - start

    def save_checkpoint(self, path: str):
        os.makedirs(path, exist_ok=True)
        self.model.save_pretrained(path)
        torch.save({"buffer": self.memory.buffer, "num_seen": self.memory.num_seen,
                    "current_step": self.current_step}, os.path.join(path, "buffer_state.pt"))

    def load_checkpoint(self, path: str):
        self.model = PeftModel.from_pretrained(self.base_model, path, is_trainable=True).to(self.device)
        state_path = os.path.join(path, "buffer_state.pt")
        if os.path.exists(state_path):
            state = torch.load(state_path)
            self.memory.buffer = state["buffer"]
            self.memory.num_seen = state["num_seen"]
            self.current_step = state["current_step"]
