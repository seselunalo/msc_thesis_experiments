"""
Reservoir Buffer (Z_t) implementation for unbiased memory sampling.

v5: stores raw (text, label) pairs. v4 stored padded token tensors, and those
could not be concatenated once two batches had been padded to different
lengths.
"""

import random
from typing import List, Optional, Tuple


class ReservoirBuffer:
    """Fixed-size reservoir: an unbiased sample of every item seen so far."""

    def __init__(self, capacity: int, seed: Optional[int] = None):
        self.capacity = capacity
        self.buffer: List[Tuple[str, int]] = []
        self.num_seen = 0
        self.rng = random.Random(seed)

    def update(self, new_samples: List[Tuple[str, int]]):
        for sample in new_samples:
            self.num_seen += 1
            if len(self.buffer) < self.capacity:
                self.buffer.append(sample)
            else:
                j = self.rng.randint(0, self.num_seen - 1)
                if j < self.capacity:
                    self.buffer[j] = sample

    def get_all(self) -> List[Tuple[str, int]]:
        return self.buffer

    def get_random_batch(self, batch_size: int) -> List[Tuple[str, int]]:
        if len(self.buffer) <= batch_size:
            return list(self.buffer)
        return self.rng.sample(self.buffer, batch_size)

    def __len__(self):
        return len(self.buffer)

    def is_empty(self):
        return len(self.buffer) == 0

    def clear(self):
        self.buffer = []
        self.num_seen = 0
