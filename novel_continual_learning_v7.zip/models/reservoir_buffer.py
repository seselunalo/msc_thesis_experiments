"""
Reservoir Buffer (Z_t) implementation for unbiased memory sampling.

v5: stores raw (text, label) pairs. v4 stored padded token tensors, and those
could not be concatenated once two batches had been padded to different
lengths.

v7.2: each stored sample also carries the era it came from (a parallel `tags`
list, so callers still get (text, label) pairs), which lets the runner log
which historical eras are still represented in the buffer. capacity=None
keeps everything ever seen ("complete available history").
"""

import random
from collections import Counter
from typing import Dict, List, Optional, Tuple


class ReservoirBuffer:
    """Fixed-size reservoir: an unbiased sample of every item seen so far."""

    def __init__(self, capacity: Optional[int], seed: Optional[int] = None):
        self.capacity = capacity                 # None = unbounded (keep the full history)
        self.buffer: List[Tuple[str, int]] = []
        self.tags: List[Optional[int]] = []      # era of each stored sample
        self.num_seen = 0
        self.rng = random.Random(seed)

    def update(self, new_samples: List[Tuple[str, int]], era: Optional[int] = None):
        for sample in new_samples:
            self.num_seen += 1
            if self.capacity is None or len(self.buffer) < self.capacity:
                self.buffer.append(sample)
                self.tags.append(era)
            else:
                j = self.rng.randint(0, self.num_seen - 1)
                if j < self.capacity:
                    self.buffer[j] = sample
                    self.tags[j] = era

    def get_all(self) -> List[Tuple[str, int]]:
        return self.buffer

    def get_random_batch(self, batch_size: int, with_tags: bool = False):
        """batch_size samples without replacement (the whole buffer if it is
        smaller). with_tags=True also returns the era of each sample."""
        if len(self.buffer) <= batch_size:
            idx = list(range(len(self.buffer)))
        else:
            idx = self.rng.sample(range(len(self.buffer)), batch_size)
        batch = [self.buffer[i] for i in idx]
        return (batch, [self.tags[i] for i in idx]) if with_tags else batch

    def era_counts(self) -> Dict[int, int]:
        """{era: number of stored samples from that era}, eras in order."""
        c = Counter(t for t in self.tags if t is not None)
        return {int(k): int(c[k]) for k in sorted(c)}

    def __len__(self):
        return len(self.buffer)

    def is_empty(self):
        return len(self.buffer) == 0

    def clear(self):
        self.buffer = []
        self.tags = []
        self.num_seen = 0
