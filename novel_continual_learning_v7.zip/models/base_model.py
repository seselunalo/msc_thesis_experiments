"""
Base model class: shared frozen base model (W), tokenizer, mini-batched
training loop and evaluation. Every model and baseline inherits from it, so
they all train and are scored in the same way.
"""

import random
import time
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from config.config import Config
from models.reservoir_buffer import ReservoirBuffer


class BaseContinualModel:
    def __init__(
        self,
        base_model_name: Optional[str] = None,
        num_labels: Optional[int] = None,
        max_length: Optional[int] = None,
        batch_size: Optional[int] = None,
        device: str = Config.DEVICE,
        seed: int = Config.RANDOM_SEED,
    ):
        # Read Config at call time so the runner can override it (e.g. --model).
        self.base_model_name = base_model_name or Config.BASE_MODEL_NAME
        self.num_labels = num_labels or Config.NUM_LABELS
        self.max_length = max_length or Config.MAX_LENGTH
        self.batch_size = batch_size or Config.BATCH_SIZE
        self.device = device
        self.seed = seed
        self.rng = random.Random(seed)
        torch.manual_seed(seed)

        self.tokenizer = AutoTokenizer.from_pretrained(self.base_model_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.use_bf16 = device == "cuda" and torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        self.base_model = self._load_base_model()
        self.model = self.base_model
        print(f"Base model (W) loaded: {self.get_total_parameters():,} parameters (FROZEN)")

    # ------------------------------------------------------------------ setup
    def _load_base_model(self) -> AutoModelForSequenceClassification:
        """Load the pre-trained model with a fresh classification head, all frozen."""
        model = AutoModelForSequenceClassification.from_pretrained(
            self.base_model_name, num_labels=self.num_labels)
        model.config.pad_token_id = self.tokenizer.pad_token_id
        for p in model.parameters():
            p.requires_grad = False
        return model.to(self.device)

    def resolve_ft_mode(self) -> str:
        mode = Config.FULL_FT_MODE
        if mode == "auto":
            big = (torch.cuda.is_available() and
                   torch.cuda.get_device_properties(0).total_memory / 1024 ** 3 >= 30)
            mode = "full" if big else "lora"
        return mode

    def _make_adaptable(self, model, mode: str):
        """Make `model` trainable for Naive FT / Periodic. Returns (model, learning rate)."""
        if mode == "lora":
            from peft import LoraConfig, TaskType, get_peft_model
            cfg = LoraConfig(task_type=TaskType.SEQ_CLS, r=Config.LORA_R, lora_alpha=Config.LORA_ALPHA,
                             lora_dropout=Config.LORA_DROPOUT, target_modules=Config.LORA_TARGET_MODULES,
                             bias="none")
            return get_peft_model(model, cfg).to(self.device), Config.LEARNING_RATE
        for p in model.parameters():
            p.requires_grad = True
        if Config.GRADIENT_CHECKPOINTING and self.device == "cuda":
            model.gradient_checkpointing_enable()
            model.config.use_cache = False
        return model, Config.FULL_FT_LEARNING_RATE

    @staticmethod
    def _head_parameters(model) -> List[torch.nn.Parameter]:
        """Parameters of the classification head ('score' for Qwen, 'classifier' elsewhere)."""
        return [p for n, p in model.named_parameters()
                if n.split(".")[0] in ("score", "classifier") or ".score." in n or ".classifier." in n]

    def _tokenize(self, texts: List[str]) -> Tuple[torch.Tensor, torch.Tensor]:
        enc = self.tokenizer(texts, padding=True, truncation=True,
                             return_tensors="pt", max_length=self.max_length)
        return enc["input_ids"].to(self.device), enc["attention_mask"].to(self.device)

    # --------------------------------------------------------------- training
    def _init_exposure(self):
        """v7.2: counters of what each arm actually trains on, so arms can be
        compared at equal exposure (supervisor's equal-exposure control)."""
        self.exposure = {"optimizer_updates": 0, "examples_processed": 0, "new_examples": 0,
                         "replay_examples": 0, "resampled_examples": 0,
                         "tokens_processed": 0, "padded_tokens_processed": 0}
        self.era_log = []          # one dict per era (see _log_era)
        self._era_draws = {}       # era -> replayed samples drawn from it during the current era

    def _count(self, key, n):
        if not hasattr(self, "exposure"):
            self._init_exposure()
        self.exposure[key] += int(n)

    def _fit(
        self,
        model,
        optimizer,
        texts: List[str],
        labels: List[int],
        epochs: int,
        replay=None,
        replay_batch_size: int = 0,
        extra_loss=None,
        resample_per_batch: int = 0,
    ) -> float:
        """Mini-batched training. If a replay buffer is given, each mini-batch
        of new data is joined by `replay_batch_size` samples drawn from it.
        `resample_per_batch` > 0 instead adds that many extra samples drawn
        again from the current era's own data (the equal-exposure, no-replay
        control). `extra_loss(model)`, if given, is added to the task loss
        (O-LoRA's orthogonality penalty); the reported loss is the task loss only.

        Every call counts optimizer updates, examples and tokens (non-padding
        and padded) into self.exposure (v7.2)."""
        if not hasattr(self, "exposure"):
            self._init_exposure()
        if resample_per_batch and not hasattr(self, "_resample_rng"):
            # a separate generator, so resampling does not change the batch order
            self._resample_rng = random.Random(self.seed + 7919)
        model.train()
        params = [p for p in model.parameters() if p.requires_grad]
        idx = list(range(len(texts)))
        losses = []
        for _ in range(epochs):
            self.rng.shuffle(idx)
            for i in range(0, len(idx), self.batch_size):
                b = idx[i:i + self.batch_size]
                bt = [texts[j] for j in b]
                bl = [labels[j] for j in b]
                self._count("new_examples", len(b))
                if replay is not None and replay_batch_size and not replay.is_empty():
                    batch, tags = replay.get_random_batch(replay_batch_size, with_tags=True)
                    for (t, y), era in zip(batch, tags):
                        bt.append(t)
                        bl.append(y)
                        self._era_draws[era] = self._era_draws.get(era, 0) + 1
                    self._count("replay_examples", len(batch))
                elif resample_per_batch:
                    for j in self._resample_rng.choices(range(len(texts)), k=resample_per_batch):
                        bt.append(texts[j])
                        bl.append(labels[j])
                    self._count("resampled_examples", resample_per_batch)
                ids, mask = self._tokenize(bt)
                y = torch.tensor(bl, device=self.device)
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=self.use_bf16):
                    out = model(input_ids=ids, attention_mask=mask, labels=y, return_dict=True)
                optimizer.zero_grad(set_to_none=True)
                total = out.loss if extra_loss is None else out.loss + extra_loss(model)
                total.backward()
                torch.nn.utils.clip_grad_norm_(params, Config.MAX_GRAD_NORM)
                optimizer.step()
                self._count("optimizer_updates", 1)
                self._count("examples_processed", len(bt))
                self._count("tokens_processed", int(mask.sum().item()))
                self._count("padded_tokens_processed", mask.numel())
                losses.append(out.loss.item())
        return float(np.mean(losses)) if losses else 0.0

    # ------------------------------------------------------------ replay (v7.2)
    def _setup_replay(self, replay_mode: str, buffer_capacity, replay_batch_size: int, seed: int):
        """replay_mode:
            "replay"  - reservoir buffer of `buffer_capacity` (None = full history);
                        `replay_batch_size` buffer samples join every mini-batch.
            "none"    - no replay.
            "matched" - no replay, but every mini-batch gets as many extra samples
                        (resampled from the current era) as the replay arm would add,
                        so both arms take the same optimizer updates on the same
                        number of examples. A shadow reservoir of the same capacity
                        is kept only to know how many the replay arm would add.
        A capacity of 0 means no replay (kept from v7.1's --buffer-capacity 0)."""
        if replay_mode == "replay" and buffer_capacity == 0:
            replay_mode = "none"
        self.replay_mode = replay_mode
        self.replay_batch_size = replay_batch_size if replay_mode != "none" else 0
        self.buffer_capacity = buffer_capacity
        self.memory = (ReservoirBuffer(capacity=buffer_capacity, seed=seed)
                       if replay_mode in ("replay", "matched") else None)
        self.era_idx = 0
        self._init_exposure()

    def _replay_fit(self, model, optimizer, texts, labels, epochs, extra_loss=None) -> float:
        """Train one era under self.replay_mode, then update the buffer and log the era."""
        before = dict(self.exposure)
        self._era_draws = {}
        if self.replay_mode == "replay":
            loss = self._fit(model, optimizer, texts, labels, epochs, replay=self.memory,
                             replay_batch_size=self.replay_batch_size, extra_loss=extra_loss)
        elif self.replay_mode == "matched":
            k = min(self.replay_batch_size, len(self.memory)) if self.memory is not None else 0
            loss = self._fit(model, optimizer, texts, labels, epochs, extra_loss=extra_loss,
                             resample_per_batch=k)
        else:
            loss = self._fit(model, optimizer, texts, labels, epochs, extra_loss=extra_loss)
        if self.memory is not None:
            # updated after the era, so replay only ever holds past eras
            self.memory.update(list(zip(texts, labels)), era=self.era_idx)
        self._log_era(before)
        self.era_idx += 1
        return loss

    def _log_era(self, before):
        entry = {"era": self.era_idx,
                 **{k: self.exposure[k] - before.get(k, 0) for k in self.exposure}}
        if self.memory is not None:
            counts = self.memory.era_counts()
            entry.update({
                "buffer_occupancy": len(self.memory),
                "buffer_capacity": self.memory.capacity,
                "buffer_num_seen": self.memory.num_seen,
                "buffer_era_counts": {str(k): v for k, v in counts.items()},
                "buffer_eras_represented": len(counts),
                "eras_seen": self.era_idx + 1,
            })
            if self.replay_mode == "replay":
                entry["replay_draws_by_era"] = {str(k): v for k, v in sorted(
                    self._era_draws.items(), key=lambda kv: (kv[0] is None, kv[0]))}
        self.era_log.append(entry)

    def exposure_report(self) -> Dict:
        """Totals and per-era log, merged into the run's results by the runner."""
        if not hasattr(self, "exposure"):
            return {}
        out = dict(self.exposure)
        out["replay_mode"] = getattr(self, "replay_mode", "none")
        out["replay_batch_size"] = getattr(self, "replay_batch_size", 0)
        cap = getattr(self, "buffer_capacity", None) if getattr(self, "memory", None) is not None else 0
        out["buffer_capacity"] = "all" if cap is None else cap
        out["era_log"] = self.era_log
        return out

    def train_step(self, texts: List[str], labels: List[int]) -> Tuple[Optional[float], float]:
        """Train on one era. Returns (mean loss, seconds). The loss is None
        when the method does no training in this era (Static after era 1,
        Periodic between retrains)."""
        raise NotImplementedError

    # ------------------------------------------------------------- evaluation
    @torch.no_grad()
    def predict(self, texts: List[str]) -> List[int]:
        self.model.eval()
        preds = []
        for i in range(0, len(texts), Config.EVAL_BATCH_SIZE):
            ids, mask = self._tokenize(texts[i:i + Config.EVAL_BATCH_SIZE])
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=self.use_bf16):
                logits = self.model(input_ids=ids, attention_mask=mask, return_dict=True).logits
            preds.extend(logits.argmax(dim=-1).cpu().tolist())
        return preds

    def evaluate(self, texts: List[str], labels: List[int]) -> Dict[str, float]:
        preds = self.predict(texts)
        return {
            "accuracy": accuracy_score(labels, preds),
            "macro_f1": f1_score(labels, preds, average="macro",
                                 labels=list(range(self.num_labels)), zero_division=0),
        }

    # ---------------------------------------------------------------- cleanup
    def release(self):
        """Drop every reference to GPU tensors (model, base model, optimizer,
        head) so the runner can free the memory before the next method. Called
        even if the run crashed, so a failed method does not leave its weights
        on the GPU."""
        for attr in ("optimizer", "model", "base_model", "head", "memory"):
            if hasattr(self, attr):
                setattr(self, attr, None)

    # ----------------------------------------------------------------- counts
    def get_trainable_parameters(self) -> int:
        return sum(p.numel() for p in self.model.parameters() if p.requires_grad)

    def get_total_parameters(self) -> int:
        return sum(p.numel() for p in self.model.parameters())
