"""
Base model class: shared frozen base model (W), tokenizer, mini-batched
training loop and evaluation. Every model and baseline inherits from it, so
they all train and are scored in the same way.
"""

import random
import time
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from config.config import Config


class BaseContinualModel:
    def __init__(
        self,
        base_model_name: Optional[str] = None,
        num_labels: Optional[int] = None,
        max_length: Optional[int] = None,
        batch_size: Optional[int] = None,
        device: str = Config.DEVICE,
        seed: int = Config.RANDOM_SEED,
    ):
        # Read Config at call time so the runner can override it (e.g. --model).
        self.base_model_name = base_model_name or Config.BASE_MODEL_NAME
        self.num_labels = num_labels or Config.NUM_LABELS
        self.max_length = max_length or Config.MAX_LENGTH
        self.batch_size = batch_size or Config.BATCH_SIZE
        self.device = device
        self.seed = seed
        self.rng = random.Random(seed)
        torch.manual_seed(seed)

        self.tokenizer = AutoTokenizer.from_pretrained(self.base_model_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.use_bf16 = device == "cuda" and torch.cuda.is_available() and torch.cuda.is_bf16_supported()
        self.base_model = self._load_base_model()
        self.model = self.base_model
        print(f"Base model (W) loaded: {self.get_total_parameters():,} parameters (FROZEN)")

    # ------------------------------------------------------------------ setup
    def _load_base_model(self) -> AutoModelForSequenceClassification:
        """Load the pre-trained model with a fresh classification head, all frozen."""
        model = AutoModelForSequenceClassification.from_pretrained(
            self.base_model_name, num_labels=self.num_labels)
        model.config.pad_token_id = self.tokenizer.pad_token_id
        for p in model.parameters():
            p.requires_grad = False
        return model.to(self.device)

    def resolve_ft_mode(self) -> str:
        mode = Config.FULL_FT_MODE
        if mode == "auto":
            big = (torch.cuda.is_available() and
                   torch.cuda.get_device_properties(0).total_memory / 1024 ** 3 >= 30)
            mode = "full" if big else "lora"
        return mode

    def _make_adaptable(self, model, mode: str):
        """Make `model` trainable for Naive FT / Periodic. Returns (model, learning rate)."""
        if mode == "lora":
            from peft import LoraConfig, TaskType, get_peft_model
            cfg = LoraConfig(task_type=TaskType.SEQ_CLS, r=Config.LORA_R, lora_alpha=Config.LORA_ALPHA,
                             lora_dropout=Config.LORA_DROPOUT, target_modules=Config.LORA_TARGET_MODULES,
                             bias="none")
            return get_peft_model(model, cfg).to(self.device), Config.LEARNING_RATE
        for p in model.parameters():
            p.requires_grad = True
        if Config.GRADIENT_CHECKPOINTING and self.device == "cuda":
            model.gradient_checkpointing_enable()
            model.config.use_cache = False
        return model, Config.FULL_FT_LEARNING_RATE

    @staticmethod
    def _head_parameters(model) -> List[torch.nn.Parameter]:
        """Parameters of the classification head ('score' for Qwen, 'classifier' elsewhere)."""
        return [p for n, p in model.named_parameters()
                if n.split(".")[0] in ("score", "classifier") or ".score." in n or ".classifier." in n]

    def _tokenize(self, texts: List[str]) -> Tuple[torch.Tensor, torch.Tensor]:
        enc = self.tokenizer(texts, padding=True, truncation=True,
                             return_tensors="pt", max_length=self.max_length)
        return enc["input_ids"].to(self.device), enc["attention_mask"].to(self.device)

    # --------------------------------------------------------------- training
    def _fit(
        self,
        model,
        optimizer,
        texts: List[str],
        labels: List[int],
        epochs: int,
        replay=None,
        replay_batch_size: int = 0,
        extra_loss=None,
    ) -> float:
        """Mini-batched training. If a replay buffer is given, each mini-batch
        of new data is joined by `replay_batch_size` samples drawn from it.
        `extra_loss(model)`, if given, is added to the task loss (O-LoRA's
        orthogonality penalty); the reported loss is the task loss only."""
        model.train()
        params = [p for p in model.parameters() if p.requires_grad]
        idx = list(range(len(texts)))
        losses = []
        for _ in range(epochs):
            self.rng.shuffle(idx)
            for i in range(0, len(idx), self.batch_size):
                b = idx[i:i + self.batch_size]
                bt = [texts[j] for j in b]
                bl = [labels[j] for j in b]
                if replay is not None and replay_batch_size and not replay.is_empty():
                    for t, y in replay.get_random_batch(replay_batch_size):
                        bt.append(t)
                        bl.append(y)
                ids, mask = self._tokenize(bt)
                y = torch.tensor(bl, device=self.device)
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=self.use_bf16):
                    out = model(input_ids=ids, attention_mask=mask, labels=y, return_dict=True)
                optimizer.zero_grad(set_to_none=True)
                total = out.loss if extra_loss is None else out.loss + extra_loss(model)
                total.backward()
                torch.nn.utils.clip_grad_norm_(params, Config.MAX_GRAD_NORM)
                optimizer.step()
                losses.append(out.loss.item())
        return float(np.mean(losses)) if losses else 0.0

    def train_step(self, texts: List[str], labels: List[int]) -> Tuple[Optional[float], float]:
        """Train on one era. Returns (mean loss, seconds). The loss is None
        when the method does no training in this era (Static after era 1,
        Periodic between retrains)."""
        raise NotImplementedError

    # ------------------------------------------------------------- evaluation
    @torch.no_grad()
    def predict(self, texts: List[str]) -> List[int]:
        self.model.eval()
        preds = []
        for i in range(0, len(texts), Config.EVAL_BATCH_SIZE):
            ids, mask = self._tokenize(texts[i:i + Config.EVAL_BATCH_SIZE])
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=self.use_bf16):
                logits = self.model(input_ids=ids, attention_mask=mask, return_dict=True).logits
            preds.extend(logits.argmax(dim=-1).cpu().tolist())
        return preds

    def evaluate(self, texts: List[str], labels: List[int]) -> Dict[str, float]:
        preds = self.predict(texts)
        return {
            "accuracy": accuracy_score(labels, preds),
            "macro_f1": f1_score(labels, preds, average="macro",
                                 labels=list(range(self.num_labels)), zero_division=0),
        }

    # ---------------------------------------------------------------- cleanup
    def release(self):
        """Drop every reference to GPU tensors (model, base model, optimizer,
        head) so the runner can free the memory before the next method. Called
        even if the run crashed, so a failed method does not leave its weights
        on the GPU."""
        for attr in ("optimizer", "model", "base_model", "head", "memory"):
            if hasattr(self, attr):
                setattr(self, attr, None)

    # ----------------------------------------------------------------- counts
    def get_trainable_parameters(self) -> int:
        return sum(p.numel() for p in self.model.parameters() if p.requires_grad)

    def get_total_parameters(self) -> int:
        return sum(p.numel() for p in self.model.parameters())
