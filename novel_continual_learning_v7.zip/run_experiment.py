#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_experiment.py (v7.2)

Unified experiment runner for the Novel Continual Learning thesis.

Performs:
    1. Environment setup (memory, logging, persistent storage)
    2. Data setup (synthetic generation/loading, Sheng loading)
    3. Model training and evaluation (all baselines + novel) on BOTH datasets
    4. Summary report with metrics and resource usage

Separate summaries are produced for synthetic and real-world Sheng data.

Changes from the version shared on 2026-11-14:
    - Each era has a held-out test split. Models are evaluated on test data,
      not on the batches they were trained on.
    - Synthetic defaults come from Config: 10 eras x 1,000 samples (80/20 split; 20 before v7.1).
      --quick uses 5 eras x 200.
    - Sheng runs all four models, with 5 merged eras (Config.NUM_SHENG_ERAS).
    - Three-class labels. A Macro-F1 column is added to the summary tables.
    - Checkpointing records finished (dataset, model) pairs, so --resume
      skips exactly what has already run.
    - --models / --datasets run a subset; --model overrides the base model
      (e.g. a smaller one for a smoke test).

v6 (2026-11-16):
    - --seeds 42 43 44 45 46 runs every model on every dataset once per seed,
      seeding Python, NumPy, PyTorch (CPU and GPU) and Transformers before each
      run. The data stay fixed (--data-seed), so seeds vary only the model
      (head and LoRA initialisation, dropout, batch order, replay sampling).
    - Seeds are now passed to the models explicitly. In v5 the models' `seed`
      defaults were bound at import time, so --seed only changed the data.
    - --resume works per (seed, dataset, model), and the checkpoint is written
      atomically, so a Colab disconnect loses at most the run in progress.
    - Per-seed results files plus a mean ± std summary (.md, .csv, .json) for
      AA, AF, FWT, BWT, Macro-F1 and time.
    - GPU memory is freed after every method, also when one crashes; a failed
      run is logged and the others carry on (--stop-on-error to stop).
    - Three LoRA-variant baselines under the Naive FT protocol: DoRA, LoRA+ and
      O-LoRA (--models dora,loraplus,olora, or the group "variants").
    - Each run records wall and train time, CPU % (process and system), peak
      RAM (RSS) and peak GPU memory; the summary reports their mean ± std.
    - Static (after era 1) and Periodic (between retrains) log "loss=n/a"
      instead of 0.0000, since they do not train in those eras.

v7 (2026-11-16), for SLURM clusters such as KENET's Chui:
    - Storage root from --storage-root or EXPERIMENT_ROOT (default
      ./experiment_data); no Colab / Google Drive / Lightning detection.
    - Each finished (seed, dataset, model) run is saved as its own file under
      checkpoints/v7_<settings hash>/, written atomically. Several SLURM array
      tasks can therefore run different seeds or models at the same time
      without overwriting each other's progress. --resume reads these files.
    - --prepare-data generates the synthetic stream and checks the Sheng
      files, then exits. Inside a SLURM array task the runner never generates
      data itself (parallel tasks would race on the same folder).
    - --aggregate-only builds the mean ± std summary from every finished run
      on disk (for example after all array tasks end) without training.
    - A missing Sheng export is an error, not a silent skip.
    - Experiment IDs include the SLURM job and array task, and the log and
      results record the SLURM job, node and partition.

v7.2 (2026-11-27), supervisor's replay study:
    - Full fine-tuning with and without replay: "Naive FT + replay" uses Novel's
      reservoir buffer and replay ratio under full fine-tuning (naive_replay).
    - Buffer capacity sweep: --buffer-capacity 64 / 256 / 1000 / all, with the
      replay ratio (--replay-batch per mini-batch of 16 new samples) held fixed.
      Every run logs, per era, the buffer occupancy, how many samples of each
      past era it still holds, and how many replayed samples came from each era.
    - Equal-exposure control: "Novel (matched)" and "Naive FT (matched)" use no
      replay but top every mini-batch up with resampled current-era data, so
      they take the same optimizer updates on the same number of examples as
      their replay arm. Every run (all methods) records optimizer updates,
      examples (new / replayed / resampled) and tokens processed, in total and
      per era; the summary adds them as columns.
    - --models replay_study runs the 2 x 3 design; tools/replay_study_report.py
      builds the tables for it from all stores on disk.

Author: Frederick Sesera
Thesis: Adaptive NLP for Rapidly Evolving Languages
Year: 2026
"""

import os
import sys
import json
import time
import argparse
import hashlib
import math
import platform
from datetime import datetime

import torch
import numpy as np
import psutil

# =====================================================================
# 1. ENVIRONMENT SETUP
# =====================================================================

os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True,max_split_size_mb:512"
try:
    sys.stdout.reconfigure(encoding="utf-8")      # emoji-safe on Windows consoles
except Exception:
    pass


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config.paths import (STORAGE_ROOT, PROJECT_DIR, DATA_DIR, SYNTHETIC_DIR,  # noqa: E402
                          SHENG_DIR, LOGS_DIR, CHECKPOINT_DIR)

for d in [PROJECT_DIR, DATA_DIR, SYNTHETIC_DIR, SHENG_DIR, LOGS_DIR, CHECKPOINT_DIR]:
    os.makedirs(d, exist_ok=True)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.config import Config
from data.synthetic_data_generator import generate_synthetic_data
from data.data_loader import load_synthetic_batches, load_sheng_batches
from models.novel_model import NovelContinualLearningModel
from baselines.baseline_static import BaselineStatic
from baselines.baseline_naive_ft import BaselineNaiveFT
from baselines.baseline_periodic import BaselinePeriodic
from baselines.baseline_lora_variants import BaselineDoRA, BaselineLoRAPlus, BaselineOLoRA
from evaluation.continual_learning_evaluator import ContinualLearningEvaluator
from utils.seeding import set_all_seeds, free_gpu_memory
from utils.resource_monitor import ResourceMonitor

MODELS = {
    "Static": (BaselineStatic, {}),
    "Naive FT": (BaselineNaiveFT, {}),
    "Periodic": (BaselinePeriodic, {}),
    "Novel": (NovelContinualLearningModel, {}),
    "DoRA": (BaselineDoRA, {}),
    "LoRA+": (BaselineLoRAPlus, {}),
    "O-LoRA": (BaselineOLoRA, {}),
    # v7.2 replay study (supervisor's comments): update method x replay arm.
    # "matched" = no replay, but the same optimizer updates and examples as the
    # replay arm, by topping each mini-batch up with resampled current-era data.
    "Novel (no replay)": (NovelContinualLearningModel, {"replay_mode": "none"}),
    "Novel (matched)": (NovelContinualLearningModel, {"replay_mode": "matched"}),
    "Naive FT + replay": (BaselineNaiveFT, {"replay_mode": "replay"}),
    "Naive FT (matched)": (BaselineNaiveFT, {"replay_mode": "matched"}),
}
MODEL_KEYS = {"static": "Static", "naive": "Naive FT", "periodic": "Periodic", "novel": "Novel",
              "dora": "DoRA", "loraplus": "LoRA+", "olora": "O-LoRA",
              "novel_noreplay": "Novel (no replay)", "novel_matched": "Novel (matched)",
              "naive_replay": "Naive FT + replay", "naive_matched": "Naive FT (matched)"}
CORE_MODELS = "static,naive,periodic,novel"
LORA_VARIANTS = "dora,loraplus,olora"
# 2 x 3 design: {LoRA adapter, full fine-tuning} x {replay, no replay, no replay at equal exposure}
REPLAY_STUDY = "novel,novel_noreplay,novel_matched,naive,naive_replay,naive_matched"
REPLAY_ARMS = {"Novel", "Novel (no replay)", "Novel (matched)",
               "Naive FT", "Naive FT + replay", "Naive FT (matched)"}

# =====================================================================
# 2. LOGGING AND UTILITIES
# =====================================================================


class ExperimentLogger:
    def __init__(self, log_dir=LOGS_DIR):
        self.log_dir = log_dir
        self.experiment_id = datetime.now().strftime("%Y%m%d_%H%M%S") + slurm_suffix()
        self.log_file = os.path.join(log_dir, f"experiment_{self.experiment_id}.log")
        self.system_info = {}

    def start(self):
        self._capture_system_info()
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n" + f"EXPERIMENT LOG: {self.experiment_id}\n" + "=" * 80 + "\n")
            for k, v in self.system_info.items():
                f.write(f"  {k}: {v}\n")
            f.write("=" * 80 + "\n\n")
        return self.log_file

    def _capture_system_info(self):
        self.system_info = {
            "experiment_id": self.experiment_id,
            "timestamp": datetime.now().isoformat(),
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "hostname": platform.node(),
            "cpu_count": psutil.cpu_count(),
            "memory_total_gb": round(psutil.virtual_memory().total / 1024 ** 3, 2),
            "storage_root": STORAGE_ROOT,
            "base_model": Config.BASE_MODEL_NAME,
            "num_labels": Config.NUM_LABELS,
            "data_seed": Config.RANDOM_SEED,
        }
        if torch.cuda.is_available():
            self.system_info["gpu_name"] = torch.cuda.get_device_name(0)
            self.system_info["gpu_memory_total_gb"] = round(
                torch.cuda.get_device_properties(0).total_memory / 1024 ** 3, 2)
            self.system_info["cuda_version"] = torch.version.cuda
        self.system_info["torch_version"] = torch.__version__
        for k in ("SLURM_JOB_ID", "SLURM_ARRAY_JOB_ID", "SLURM_ARRAY_TASK_ID", "SLURM_JOB_PARTITION",
                  "SLURM_JOB_NODELIST", "SLURM_CPUS_PER_TASK"):
            if os.environ.get(k):
                self.system_info[k.lower()] = os.environ[k]

    def log(self, msg):
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")

    def log_data_info(self, name, num_records, size_bytes):
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"\n--- Data Info: {name} ---\n  Number of records: {num_records}\n"
                    f"  Size: {size_bytes} bytes ({size_bytes / 1024 / 1024:.2f} MB)\n")

    def log_result(self, model_name, metrics, time_seconds):
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"\n--- {model_name} ---\nTime: {time_seconds:.2f}s\n")
            for k, v in metrics.items():
                if isinstance(v, float):
                    f.write(f"  {k}: {v:.4f}\n")
                elif isinstance(v, (int, str)):
                    f.write(f"  {k}: {v}\n")

    def finish(self, total_time):
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write("\n" + "=" * 80 + f"\nTOTAL EXPERIMENT TIME: {total_time:.2f}s\n" + "=" * 80 + "\n")


def slurm_suffix():
    """'_job<array job>_<task>' or '_job<job id>' under SLURM, '' elsewhere, so
    array tasks that start in the same second never share a results file."""
    job = os.environ.get("SLURM_ARRAY_JOB_ID") or os.environ.get("SLURM_JOB_ID")
    if not job:
        return ""
    task = os.environ.get("SLURM_ARRAY_TASK_ID")
    return f"_job{job}" + (f"_{task}" if task else "")


_UNSET = object()


def _capacity(v):
    """--buffer-capacity: a whole number >= 0, or 'all' (None = keep everything)."""
    if str(v).lower() in ("all", "full", "inf"):
        return None
    n = int(v)
    if n < 0:
        raise argparse.ArgumentTypeError("buffer capacity must be >= 0 or 'all'")
    return n


def in_slurm_array():
    return bool(os.environ.get("SLURM_ARRAY_TASK_ID"))


def get_dataset_size(data_dir):
    """Total records and bytes over all train and test JSONL files."""
    total_bytes = total_records = 0
    for fname in os.listdir(data_dir):
        if fname.endswith(".jsonl"):
            path = os.path.join(data_dir, fname)
            total_bytes += os.path.getsize(path)
            with open(path, "r", encoding="utf-8") as f:
                total_records += sum(1 for _ in f)
    return total_records, total_bytes


def print_separate_summary(results_by_dataset):
    """Summary table per dataset, in the agreed layout plus a Macro-F1 column."""
    for dataset_name, results in results_by_dataset.items():
        if not results:
            continue
        print("\n" + "=" * 100)
        print(f"SUMMARY FOR {dataset_name.upper()} DATA")
        print("=" * 100)
        print(f"{'Model':<26} {'AA':<8} {'AF':<8} {'FWT':<8} {'BWT':<8} {'Macro-F1':<9} "
              f"{'Time (s)':<10} {'Trainable %':<12} {'CPU %':<7} {'RAM MB':<8} {'GPU MB':<8}")
        print("-" * 100)
        for model_name, res in results.items():
            if res is None:
                continue
            print(f"{model_name:<26} {res.get('AA', 0.0):.4f}   {res.get('AF', 0.0):.4f}   "
                  f"{res.get('FWT', 0.0):.4f}   {res.get('BWT', 0.0):.4f}   "
                  f"{res.get('Macro-F1', 0.0):.4f}    {res.get('total_time_seconds', 0.0):8.2f}   "
                  f"{res.get('trainable_percentage', 0.0):9.2f}%   "
                  f"{res.get('cpu_process_percent_mean', float('nan')):5.0f}   "
                  f"{res.get('ram_peak_rss_mb', float('nan')):7.0f}  "
                  f"{res.get('gpu_peak_allocated_mb', float('nan')):7.0f}")
        print("=" * 100)

# =====================================================================
# 3. DATA SETUP
# =====================================================================


def setup_synthetic_data(num_steps, samples_per_step, allow_generate=True):
    """Load the synthetic stream, or generate it if missing or settings changed.
    With allow_generate=False (inside a SLURM array task) a missing or
    mismatched stream is an error: run --prepare-data once first."""
    meta_path = os.path.join(SYNTHETIC_DIR, "metadata.json")
    want = {"num_steps": num_steps, "samples_per_step": samples_per_step,
            "num_classes": Config.NUM_LABELS, "data_seed": Config.RANDOM_SEED,
            "test_fraction": Config.TEST_FRACTION, "generator": "v5"}
    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            if json.load(f) == want:
                print(f"✅ Loading synthetic data from {SYNTHETIC_DIR}")
                return (load_synthetic_batches(SYNTHETIC_DIR, num_steps, "train"),
                        load_synthetic_batches(SYNTHETIC_DIR, num_steps, "test"))
    if not allow_generate:
        quick = " --quick" if num_steps != Config.NUM_TIME_STEPS else ""
        sys.exit(f"❌ No synthetic data matching {want} in {SYNTHETIC_DIR}.\n"
                 f"   Array tasks do not generate data (they would overwrite each other). "
                 f"Run once first: python run_experiment.py --prepare-data{quick}")
    print(f"⚠️ Generating synthetic data to {SYNTHETIC_DIR}")
    for fname in os.listdir(SYNTHETIC_DIR):            # clear files from other settings
        if fname.endswith(".jsonl"):
            os.remove(os.path.join(SYNTHETIC_DIR, fname))
    train, test, _ = generate_synthetic_data(
        num_time_steps=num_steps, samples_per_step=samples_per_step,
        test_fraction=Config.TEST_FRACTION, num_classes=Config.NUM_LABELS,
        random_seed=Config.RANDOM_SEED, output_dir=SYNTHETIC_DIR)
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(want, f, indent=2)
    return train, test


def setup_sheng_data(num_eras, max_samples=None):
    """Load the Sheng eras written by data/export_sheng.py."""
    meta_path = os.path.join(SHENG_DIR, "metadata.json")
    if not os.path.exists(meta_path):
        print(f"⚠️ No Sheng data found in {SHENG_DIR}. Run: "
              f"python -m data.export_sheng --csv sheng_clean.csv --storage-root \"{STORAGE_ROOT}\"")
        return [], []
    with open(meta_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    if meta.get("classes") != Config.NUM_LABELS:
        print(f"⚠️ Sheng files were exported with {meta.get('classes')} classes, "
              f"but Config.NUM_LABELS = {Config.NUM_LABELS}. Re-export them.")
        return [], []
    print(f"✅ Loading Sheng data from {SHENG_DIR}")
    return (load_sheng_batches(SHENG_DIR, num_eras, "train", max_samples),
            load_sheng_batches(SHENG_DIR, num_eras, "test", max_samples))

# =====================================================================
# 4. MODEL TRAINING AND EVALUATION
# =====================================================================


def run_evaluation(model_class, model_name, stream_batches, test_batches, logger, model_params=None):
    logger.log(f"Starting evaluation of {model_name}...")
    start_time = time.time()
    model = evaluator = None
    monitor = ResourceMonitor(interval=1.0).start()   # samples CPU / RAM / GPU while this run is going
    try:
        model = model_class(**(model_params or {}))
        trainable = model.get_trainable_parameters()
        total = model.get_total_parameters()

        evaluator = ContinualLearningEvaluator(model, model_name)
        results = evaluator.evaluate_continually(stream_batches=stream_batches, test_batches=test_batches,
                                                 eval_every=Config.EVAL_EVERY, verbose=True)
        results["trainable_params"] = trainable
        results["total_params"] = total
        results["trainable_percentage"] = (trainable / total * 100) if total > 0 else 0.0
        results["total_time_seconds"] = time.time() - start_time
        # v7.2: optimizer updates, examples, tokens; buffer occupancy and era coverage per era
        if hasattr(model, "exposure_report"):
            results.update(model.exposure_report())
            print(f"🔢 {model_name}: {results.get('optimizer_updates', 0):,} optimizer updates, "
                  f"{results.get('examples_processed', 0):,} examples "
                  f"({results.get('replay_examples', 0):,} replayed, "
                  f"{results.get('resampled_examples', 0):,} resampled), "
                  f"{results.get('tokens_processed', 0):,} tokens")
            last = (results.get("era_log") or [{}])[-1]
            if "buffer_occupancy" in last and results.get("replay_mode") == "replay":
                print(f"🗂️ {model_name}: final buffer {last['buffer_occupancy']} samples from "
                      f"{last['buffer_eras_represented']} of {last['eras_seen']} eras")
        # v7.1: flag a run whose training collapsed: train loss stuck at ln(K),
        # the loss of uniform predictions (LoRA+ did this in v7). Such a run is
        # not a result to report as is.
        losses = [l for l in results.get("history", {}).get("train_loss", []) if l is not None]
        tail = losses[-3:]
        results["collapsed"] = bool(len(tail) == 3 and
                                    all(abs(l - math.log(Config.NUM_LABELS)) < 0.03 for l in tail))
        if results["collapsed"]:
            print(f"⚠️ {model_name}: training collapsed (last train losses {[round(l, 4) for l in tail]} "
                  f"≈ ln {Config.NUM_LABELS} = {math.log(Config.NUM_LABELS):.4f}, i.e. uniform predictions)")
        res_usage = monitor.stop()
        results.update(res_usage)
        print(f"📈 {model_name}: CPU {res_usage['cpu_process_percent_mean']:.0f}% "
              f"(process, 100 = 1 core; system {res_usage['cpu_system_percent_mean']:.0f}%), "
              f"peak RAM {res_usage['ram_peak_rss_mb']:.0f} MB, "
              f"peak GPU {res_usage['gpu_peak_allocated_mb']:.0f} MB")

        logger.log_result(model_name, results, results["total_time_seconds"])
        print(f"✅ {model_name} completed in {results['total_time_seconds']:.2f}s")
        return results
    finally:
        monitor.stop()                    # no-op if already stopped; stops the thread after a crash
        # v6: free GPU memory before the next method, also when this one crashed
        # (an exception's traceback keeps `model` alive, so its tensors are
        # dropped explicitly with release()).
        if model is not None:
            model.release()
        if evaluator is not None:
            evaluator.model = None
        del model, evaluator
        left = free_gpu_memory()
        if torch.cuda.is_available():
            print(f"🧹 GPU memory freed; {left:.0f} MB still allocated")
            logger.log(f"GPU memory after {model_name}: {left:.0f} MB allocated")

# =====================================================================
# 5. MULTI-SEED SUMMARY
# =====================================================================

PERF_METRICS = [("AA", "AA"), ("AF", "AF"), ("FWT", "FWT"), ("BWT", "BWT"), ("Macro-F1", "Macro-F1")]
COST_METRICS = [("Time (s)", "total_time_seconds"), ("Train time (s)", "train_time_seconds"),
                ("CPU % (process)", "cpu_process_percent_mean"), ("CPU % (system)", "cpu_system_percent_mean"),
                ("Peak RAM (MB)", "ram_peak_rss_mb"), ("Peak GPU alloc (MB)", "gpu_peak_allocated_mb"),
                ("Peak GPU reserved (MB)", "gpu_peak_reserved_mb"),
                # v7.2: exposure per arm (equal-exposure control)
                ("Optimizer updates", "optimizer_updates"), ("Examples processed", "examples_processed"),
                ("Tokens processed", "tokens_processed")]
SUMMARY_METRICS = PERF_METRICS + COST_METRICS


def aggregate_seeds(results_by_seed):
    """{seed: {dataset: {label: res}}} -> {dataset: {label: {metric: {mean, std, n, values}}}}.
    std is the sample standard deviation (ddof=1); it is 0 when only one seed has run."""
    summary = {}
    seeds = sorted(results_by_seed, key=lambda x: int(x))
    for seed in seeds:
        for ds, models in results_by_seed[seed].items():
            for label, res in models.items():
                if res is None:
                    continue
                entry = summary.setdefault(ds, {}).setdefault(label, {"seeds": []})
                entry["seeds"].append(int(seed))
                for _, key in SUMMARY_METRICS:
                    entry.setdefault(key, {"values": []})["values"].append(float(res.get(key, float("nan"))))
    for ds in summary.values():
        for entry in ds.values():
            for _, key in SUMMARY_METRICS:
                v = np.array(entry[key]["values"], dtype=float)
                entry[key]["mean"] = float(np.mean(v))
                entry[key]["std"] = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
                entry[key]["n"] = int(len(v))
    return summary


def print_multiseed_summary(summary, file=None):
    """Mean ± std over seeds, one table per dataset. Returns the Markdown text."""
    lines = []
    for ds, models in summary.items():
        for title, metrics in (("performance", PERF_METRICS), ("run time and resource use", COST_METRICS)):
            lines.append(f"\n### {ds.capitalize()} data: {title} (mean ± std over seeds)\n")
            lines.append("| Model | n | " + " | ".join(h for h, _ in metrics) + " |")
            lines.append("|---|---|" + "---|" * len(metrics))
            for label, e in models.items():
                cells = []
                for h, key in metrics:
                    fmt = "{:.4f} ± {:.4f}" if metrics is PERF_METRICS else "{:.1f} ± {:.1f}"
                    cells.append(fmt.format(e[key]["mean"], e[key]["std"]))
                lines.append(f"| {label} | {len(e['seeds'])} | " + " | ".join(cells) + " |")
    text = "\n".join(lines)
    print(text, file=file)
    return text


def save_summary(summary, results_by_seed, path_prefix):
    """Write <prefix>_summary.json, .md and .csv (one row per dataset/model)."""
    with open(path_prefix + "_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    with open(path_prefix + "_summary.md", "w", encoding="utf-8") as f:
        f.write(f"Seeds: {', '.join(sorted(results_by_seed, key=int))}\n")
        print_multiseed_summary(summary, file=f)
    with open(path_prefix + "_summary.csv", "w", encoding="utf-8") as f:
        cols = [f"{k}_{s}" for _, k in SUMMARY_METRICS for s in ("mean", "std")]
        f.write("dataset,model,n," + ",".join(cols) + "\n")
        for ds, models in summary.items():
            for label, e in models.items():
                vals = [f"{e[k][s]:.6f}" for _, k in SUMMARY_METRICS for s in ("mean", "std")]
                f.write(f"{ds},{label},{len(e['seeds'])}," + ",".join(vals) + "\n")


def _atomic_json_dump(obj, path, **kw):
    """Write to a temp file, then rename, so a job killed mid-write (time limit,
    preemption, disconnect) cannot leave a half-written, unreadable file."""
    tmp = f"{path}.tmp{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, **kw)
    os.replace(tmp, path)


MODEL_FILE_KEYS = {name: key for key, name in MODEL_KEYS.items()}   # "LoRA+" -> "loraplus"


class RunStore:
    """One JSON file per finished (seed, dataset, model) run (v7).

    Files live in checkpoints/v7_<hash of the run settings>/seed<S>/<dataset>/<model>.json,
    so runs with other settings (e.g. --quick, another base model or ft-mode)
    never mix, and concurrent SLURM array tasks each write only their own files.
    v6 kept every run in one checkpoint_v6.json, which two jobs at once would
    overwrite."""

    def __init__(self, run_key):
        digest = hashlib.sha1(json.dumps(run_key, sort_keys=True).encode()).hexdigest()[:10]
        self.dir = os.path.join(CHECKPOINT_DIR, f"v7_{digest}")
        os.makedirs(self.dir, exist_ok=True)
        key_file = os.path.join(self.dir, "run_key.json")
        if not os.path.exists(key_file):
            _atomic_json_dump(run_key, key_file, indent=2)

    def path(self, seed, ds, name):
        return os.path.join(self.dir, f"seed{seed}", ds, MODEL_FILE_KEYS[name] + ".json")

    def save(self, seed, ds, name, label, res):
        p = self.path(seed, ds, name)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        _atomic_json_dump({"seed": seed, "dataset": ds, "model": name, "label": label,
                           "finished": datetime.now().isoformat(), "result": res},
                          p, indent=2, default=float)

    def load_all(self, directory=None):
        """-> (results_by_seed {"42": {ds: {label: res}}}, done {(seed, ds, name)}).
        `directory` reads another store folder (aggregate --include-store)."""
        results_by_seed, done = {}, set()
        for root, _, files in os.walk(directory or self.dir):
            for fn in files:
                if not fn.endswith(".json") or fn == "run_key.json":
                    continue
                try:
                    with open(os.path.join(root, fn), "r", encoding="utf-8") as f:
                        d = json.load(f)
                except (OSError, ValueError) as e:
                    print(f"⚠️ Skipping unreadable run file {os.path.join(root, fn)}: {e}")
                    continue
                results_by_seed.setdefault(str(d["seed"]), {}).setdefault(d["dataset"], {})[d["label"]] = d["result"]
                done.add((int(d["seed"]), d["dataset"], d["model"]))
        return results_by_seed, done


def _sort_results(results_by_seed, model_names):
    """Order seeds numerically and models as in MODELS, so tables are stable
    whatever order the files were read or the array tasks finished in."""
    order = {}
    for i, n in enumerate(model_names):
        order[n] = i
        order[f"{n}-Sheng"] = i
    out = {}
    for seed in sorted(results_by_seed, key=int):
        out[seed] = {}
        for ds in ("synthetic", "sheng"):
            if ds in results_by_seed[seed]:
                models = results_by_seed[seed][ds]
                out[seed][ds] = {k: models[k] for k in sorted(models, key=lambda k: order.get(k, 99))}
    return out


def write_results(logger, seeds, results_by_seed, failed, model_names, datasets, prefix_name="results"):
    """Per-seed files, the combined file and the mean ± std summary for the
    requested seeds, models and datasets."""
    labels = {n if ds == "synthetic" else f"{n}-Sheng" for n in model_names for ds in datasets}
    wanted = {}
    for s in seeds:
        by_ds = results_by_seed.get(str(s), {})
        sel = {ds: {lab: r for lab, r in by_ds[ds].items() if lab in labels} for ds in datasets if ds in by_ds}
        sel = {ds: m for ds, m in sel.items() if m}
        if sel:
            wanted[str(s)] = sel
    wanted = _sort_results(wanted, list(MODELS))

    for seed, by_ds in wanted.items():
        print(f"\n######## SEED {seed} ########")
        print_separate_summary(by_ds)

    prefix = os.path.join(LOGS_DIR, f"{prefix_name}_{logger.experiment_id}")
    for seed, by_ds in wanted.items():
        with open(f"{prefix}_seed{seed}.json", "w", encoding="utf-8") as f:
            json.dump({"config": logger.system_info, "seed": int(seed), "results": by_ds},
                      f, indent=2, default=float)
    summary = aggregate_seeds(wanted)
    print("\n" + "=" * 100)
    print(f"MULTI-SEED SUMMARY (seeds: {', '.join(wanted) or 'none'})")
    print("=" * 100)
    print_multiseed_summary(summary)
    save_summary(summary, wanted, prefix)
    with open(prefix + ".json", "w", encoding="utf-8") as f:
        json.dump({"config": logger.system_info, "seeds": [int(s) for s in wanted], "results_by_seed": wanted,
                   "summary": summary, "failed": failed}, f, indent=2, default=float)
    print(f"\n📄 Results: {prefix}.json (all seeds), {prefix}_seed<N>.json (one per seed), "
          f"{prefix}_summary.md/.csv/.json (mean ± std)")
    return wanted


# =====================================================================
# 6. MAIN EXPERIMENT CONTROLLER
# =====================================================================


def main():
    parser = argparse.ArgumentParser(description="Novel Continual Learning Experiment (v7)")
    parser.add_argument("--storage-root", default=None,
                        help="where data, logs, checkpoints and results go (default: $EXPERIMENT_ROOT, "
                             f"else ./experiment_data). Now: {STORAGE_ROOT}")
    parser.add_argument("--resume", action="store_true",
                        help="Skip (seed, dataset, model) runs that already finished")
    parser.add_argument("--quick", action="store_true", help="5 eras x 200 synthetic, 50 Sheng per era")
    parser.add_argument("--models", default=CORE_MODELS + "," + LORA_VARIANTS,
                        help="comma list from: static, naive, periodic, novel, dora, loraplus, olora; "
                             "or 'core' (the first four), 'variants' (the three LoRA variants), 'all' (default: core + "
                             "variants); v7.2 also: novel_noreplay, novel_matched, naive_replay, naive_matched, "
                             "or 'replay_study' (novel, novel_noreplay, novel_matched, naive, naive_replay, naive_matched)")
    parser.add_argument("--datasets", default="synthetic,sheng", help="comma list from: synthetic, sheng")
    parser.add_argument("--model", default=None, help="override Config.BASE_MODEL_NAME")
    parser.add_argument("--seeds", type=int, nargs="+", default=None,
                        help="model seeds, e.g. --seeds 42 43 44 45 46: every model runs on every "
                             "dataset once per seed (default: Config.RANDOM_SEED; with --aggregate-only, "
                             "every seed found on disk)")
    parser.add_argument("--seed", type=int, default=None, help="single seed (same as --seeds N)")
    parser.add_argument("--data-seed", type=int, default=None,
                        help="seed for generating the synthetic stream (default: Config.RANDOM_SEED). "
                             "Kept fixed across --seeds so every seed sees the same data.")
    parser.add_argument("--ft-mode", choices=["auto", "full", "lora"], default=None,
                        help="override Config.FULL_FT_MODE for Naive FT and Periodic")
    parser.add_argument("--stop-on-error", action="store_true",
                        help="stop at the first failed run (default: log it and carry on)")
    parser.add_argument("--prepare-data", action="store_true",
                        help="generate the synthetic stream and check the Sheng files, then exit "
                             "(run once before submitting array jobs)")
    parser.add_argument("--eras", type=int, default=None,
                        help=f"synthetic eras (default Config.NUM_TIME_STEPS = {Config.NUM_TIME_STEPS}; max 20). "
                             "Run --prepare-data with the same value first.")
    parser.add_argument("--lora-r", type=int, default=None,
                        help=f"LoRA rank for every adapter method (default {Config.LORA_R}); alpha is set "
                             "to 2 x r so the update scale alpha/r stays the same (rank ablation, H5)")
    parser.add_argument("--buffer-capacity", type=_capacity, default=_UNSET,
                        help=f"replay buffer size K for Novel and Naive FT + replay (default {Config.BUFFER_CAPACITY}; "
                             "'all' keeps the complete history; 0 = no replay). The replay ratio "
                             "(--replay-batch per 16 new samples) stays fixed whatever K is.")
    parser.add_argument("--replay-batch", type=int, default=None,
                        help=f"buffer samples added to each mini-batch of 16 new ones (default {Config.REPLAY_BATCH_SIZE})")
    parser.add_argument("--include-store", action="append", default=[],
                        help="with --aggregate-only: also read finished runs from this store folder "
                             "(checkpoints/v7_<hash>); repeatable. Runs in the main store win on overlap.")
    parser.add_argument("--aggregate-only", action="store_true",
                        help="do not train: build the summary from every finished run on disk "
                             "(filtered by --seeds, --models, --datasets)")
    args = parser.parse_args()

    if args.model:
        Config.BASE_MODEL_NAME = args.model
    if args.ft_mode:
        Config.FULL_FT_MODE = args.ft_mode
    if args.data_seed is not None:
        Config.RANDOM_SEED = args.data_seed       # used only for synthetic data generation
    if args.eras is not None:
        if not 2 <= args.eras <= 20:
            parser.error("--eras must be between 2 and 20")
        Config.NUM_TIME_STEPS = args.eras
    if args.lora_r is not None:
        Config.LORA_R, Config.LORA_ALPHA = args.lora_r, 2 * args.lora_r
    if args.buffer_capacity is not _UNSET:     # None means 'all' (complete history)
        Config.BUFFER_CAPACITY = args.buffer_capacity
    if args.replay_batch is not None:
        Config.REPLAY_BATCH_SIZE = args.replay_batch
    data_seed = Config.RANDOM_SEED
    explicit_seeds = args.seeds or ([args.seed] if args.seed is not None else None)
    seeds = list(dict.fromkeys(explicit_seeds or [Config.RANDOM_SEED]))   # drop duplicates, keep order

    # Runs are only reused by a run with the same settings, so an interrupted
    # --quick run is never mistaken for part of a full run. Seeds, models and
    # datasets are not part of the key: they are tracked per run, so you can
    # add seeds or methods later and --resume keeps what is done.
    # v7.1 adds the era count and the LoRA+ learning rate, so runs made with
    # v7's 20 eras or v7's diverging LoRA+ setting are never reused.
    run_key = {"version": "v7.1", "quick": args.quick, "model": Config.BASE_MODEL_NAME,
               "labels": Config.NUM_LABELS, "data_seed": data_seed, "ft_mode": Config.FULL_FT_MODE,
               "synthetic_eras": 5 if args.quick else Config.NUM_TIME_STEPS, "loraplus_lr": Config.LORAPLUS_LR,
               "lora_r": Config.LORA_R,
               "buffer_capacity": "all" if Config.BUFFER_CAPACITY is None else Config.BUFFER_CAPACITY,
               "replay_batch": Config.REPLAY_BATCH_SIZE}
    groups = {"all": CORE_MODELS + "," + LORA_VARIANTS, "core": CORE_MODELS, "variants": LORA_VARIANTS,
              "replay_study": REPLAY_STUDY}
    keys = [k for m in args.models.split(",") if m.strip()
            for k in groups.get(m.strip().lower(), m.strip().lower()).split(",")]
    bad = [k for k in keys if k not in MODEL_KEYS]
    if bad:
        parser.error(f"unknown model(s) {bad}; choose from {sorted(MODEL_KEYS)} or core/variants/all")
    model_names = list(dict.fromkeys(MODEL_KEYS[k] for k in keys))
    datasets = [d.strip() for d in args.datasets.split(",") if d.strip()]
    bad = [d for d in datasets if d not in ("synthetic", "sheng")]
    if bad:
        parser.error(f"unknown dataset(s) {bad}; choose from synthetic, sheng")

    store = RunStore(run_key)
    print(f"💾 Storage root: {STORAGE_ROOT}")
    print(f"💾 Finished runs: {store.dir}")

    # ---- Summary only: every finished run on disk, no training
    if args.aggregate_only:
        logger = ExperimentLogger()
        logger.start()
        results_by_seed, done = {}, set()
        for extra in args.include_store:          # older stores first; the main store overrides them
            r, dn = store.load_all(os.path.expanduser(extra))
            print(f"📦 {len(dn)} run(s) from {extra}")
            for s, by_ds in r.items():
                for ds, m in by_ds.items():
                    results_by_seed.setdefault(s, {}).setdefault(ds, {}).update(m)
            done |= dn
        r, dn = store.load_all()
        for s, by_ds in r.items():
            for ds, m in by_ds.items():
                results_by_seed.setdefault(s, {}).setdefault(ds, {}).update(m)
        done |= dn
        if explicit_seeds is None:
            seeds = sorted(int(s) for s in results_by_seed)
        print(f"📦 {len(done)} finished run(s) on disk; summarising seeds {seeds}, "
              f"models {model_names}, datasets {datasets}")
        missing = [(s, d, n) for s in seeds for d in datasets for n in model_names if (s, d, n) not in done]
        if missing:
            print(f"⚠️ {len(missing)} requested run(s) not finished yet: {missing}")
        write_results(logger, seeds, results_by_seed, [list(m) for m in missing], model_names, datasets,
                      prefix_name="aggregate")
        return

    logger = ExperimentLogger()
    log_path = logger.start()
    logger.system_info["seeds"] = seeds
    logger.system_info["data_seed"] = data_seed
    logger.log(f"Seeds: {seeds}  (data seed {data_seed})")
    print(f"📋 Experiment ID: {logger.experiment_id}")
    print(f"📄 Log: {log_path}")
    print(f"🎲 Seeds: {seeds} | models: {model_names} | datasets: {datasets} | synthetic eras {Config.NUM_TIME_STEPS}, "
          f"LoRA r={Config.LORA_R} alpha={Config.LORA_ALPHA}, buffer K={'all' if Config.BUFFER_CAPACITY is None else Config.BUFFER_CAPACITY}, replay {Config.REPLAY_BATCH_SIZE}/batch")

    results_by_seed = {}                           # {"42": {"synthetic": {label: res}, "sheng": {...}}}
    done = set()                                   # {(seed, dataset, model_name)}
    if args.resume:
        results_by_seed, done = store.load_all()
        print(f"🔁 Resuming; {len(done)} run(s) with these settings already on disk")
        logger.log(f"Resuming; already done: {sorted(done)}")

    # ---- Data setup (the same data for every seed)
    logger.log("Setting up data...")
    allow_generate = args.prepare_data or not in_slurm_array()
    streams = {}
    if "synthetic" in datasets:
        steps, per_step = (5, 200) if args.quick else (Config.NUM_TIME_STEPS, Config.SAMPLES_PER_STEP)
        streams["synthetic"] = setup_synthetic_data(steps, per_step, allow_generate)
        n, b = get_dataset_size(SYNTHETIC_DIR)
        logger.log_data_info("Synthetic", n, b)
        print(f"📊 Synthetic data: {n} records, {b / 1024 / 1024:.2f} MB")
    if "sheng" in datasets:
        train, test = setup_sheng_data(Config.NUM_SHENG_ERAS, 50 if args.quick else None)
        if not train:
            sys.exit("❌ Sheng data missing or invalid (see above). Export it, or leave it out with "
                     "--datasets synthetic.")
        streams["sheng"] = (train, test)
        n, b = get_dataset_size(SHENG_DIR)
        logger.log_data_info("Sheng", n, b)
        print(f"📊 Sheng data: {n} records, {b / 1024 / 1024:.2f} MB")

    if args.prepare_data:
        print(f"✅ Data ready under {DATA_DIR}")
        return

    # ---- Every model on every dataset, once per seed
    failed = []
    total_runs = len(seeds) * len(streams) * len(model_names)
    run_no = 0
    for seed in seeds:
        seed_results = results_by_seed.setdefault(str(seed), {})
        for ds, (train, test) in streams.items():
            print("\n" + "=" * 80)
            print(f"SEED {seed} | RUNNING ON {ds.upper()} DATA")
            print("=" * 80)
            for name in model_names:
                run_no += 1
                label = name if ds == "synthetic" else f"{name}-Sheng"
                if (seed, ds, name) in done:
                    print(f"⏭️ [{run_no}/{total_runs}] Skipping {label}, seed {seed} (already done)")
                    continue
                print(f"\n▶️ [{run_no}/{total_runs}] {label}, seed {seed}", flush=True)
                logger.log(f"Seed {seed}: {label}")
                set_all_seeds(seed)
                cls, params = MODELS[name]
                params = dict(params, seed=seed)
                if cls is NovelContinualLearningModel:   # keyword defaults were bound at import time
                    params.update(lora_r=Config.LORA_R, lora_alpha=Config.LORA_ALPHA,
                                  buffer_capacity=Config.BUFFER_CAPACITY,
                                  replay_batch_size=Config.REPLAY_BATCH_SIZE)
                elif name in REPLAY_ARMS:             # Naive FT arms of the replay study
                    params.update(buffer_capacity=Config.BUFFER_CAPACITY,
                                  replay_batch_size=Config.REPLAY_BATCH_SIZE)
                try:
                    res = run_evaluation(cls, label, train, test, logger, params)
                except Exception as e:  # noqa: BLE001  (e.g. CUDA out of memory)
                    msg = f"{label}, seed {seed} failed: {type(e).__name__}: {e}"
                    print(f"❌ {msg}", flush=True)
                    logger.log(msg)
                    failed.append((seed, ds, name))
                    if args.stop_on_error:
                        raise
                    continue
                res["seed"] = seed
                seed_results.setdefault(ds, {})[label] = res
                done.add((seed, ds, name))
                store.save(seed, ds, name, label, res)

    total_time = sum(results_by_seed.get(str(s), {}).get(ds, {}).get(n if ds == "synthetic" else f"{n}-Sheng",
                                                                     {}).get("total_time_seconds", 0.0)
                     for s in seeds for ds in streams for n in model_names)
    logger.finish(total_time)
    # Only the seeds, models and datasets asked for in this run go into the
    # summary, even if the run store holds more from other jobs.
    write_results(logger, seeds, results_by_seed, failed, model_names, list(streams))

    if failed:
        print(f"⚠️ {len(failed)} run(s) failed: {failed}. Re-run with --resume to retry only those.")
        print(f"   Finished runs are kept in {store.dir}")
        sys.exit(1)
    print(f"✅ Experiment complete. Log saved to {log_path}")


if __name__ == "__main__":
    main()
