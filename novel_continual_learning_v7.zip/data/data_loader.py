"""
Data loading utilities for the synthetic and Sheng streams (v5).

Each era has a training file and a held-out test file:
    synthetic: batch_XXX.jsonl / test_XXX.jsonl
    sheng:     sheng_era_N.jsonl / sheng_era_N_test.jsonl
Each line is {"text": ..., "label": int}.
"""

import json
import os
from typing import List, Optional, Tuple

from config.config import Config

Batch = Tuple[List[str], List[int]]


def _read_jsonl(path: str, max_samples: Optional[int] = None) -> Batch:
    texts, labels = [], []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            texts.append(d["text"])
            labels.append(int(d["label"]))
    if max_samples is not None:
        texts, labels = texts[:max_samples], labels[:max_samples]
    return texts, labels


def load_synthetic_batches(data_dir: str, num_batches: int = Config.NUM_TIME_STEPS,
                           split: str = "train", max_samples: Optional[int] = None) -> List[Batch]:
    prefix = "batch" if split == "train" else "test"
    return [_read_jsonl(os.path.join(data_dir, f"{prefix}_{t:03d}.jsonl"), max_samples)
            for t in range(1, num_batches + 1)]


def load_sheng_batches(data_dir: str, num_eras: int = Config.NUM_SHENG_ERAS,
                       split: str = "train", max_samples: Optional[int] = None) -> List[Batch]:
    suffix = "" if split == "train" else "_test"
    return [_read_jsonl(os.path.join(data_dir, f"sheng_era_{e}{suffix}.jsonl"), max_samples)
            for e in range(1, num_eras + 1)]
