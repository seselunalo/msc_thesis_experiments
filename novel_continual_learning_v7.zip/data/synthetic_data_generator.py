"""
Synthetic language-evolution stream (thesis section 3.4.1), v5.

The stream is made of short "posts" in an artificial, Sheng-like vocabulary
(generated CV-syllable pseudo-words), with three-class sentiment labels
(0 Negative, 1 Neutral, 2 Positive). Lexical drift events are planted at known
eras, so forgetting and adaptation can be measured against ground truth.

How a post is built
- The label is drawn from the era's class prior. Sentiment cues are then
  sampled so that the summed polarity matches the label: Positive > 0,
  Negative < 0, and Neutral = 0 (no cues, or one positive and one negative cue).
- A cue may be written as negator + opposite-polarity word, which tests
  simple composition.
- Topic (polarity 0) and function words fill the post to 6-14 tokens.
- Labels are flipped at random with probability `label_noise`.

Drift events (DRIFT_SCHEDULE is written for 20 eras and is rescaled for
shorter streams):
- emerge:   new terms enter with a polarity and high usage (new slang).
- obsolete: existing sentiment terms fade out and are then retired.
- shift:    a term changes meaning (e.g. positive -> neutral, neutral -> negative).
- reverse:  a set of terms flips polarity, positive <-> negative.
- revert:   an earlier reversal is undone (a recurring concept, which tests memory).
- prior:    the class balance changes.

Files written to output_dir:
    batch_XXX.jsonl   training split of era XXX   {"text", "label"}
    test_XXX.jsonl    held-out test split of era XXX
    evolution_log.json  the applied events, the words involved and the settings
    lexicon.csv       per-era state of every word (polarity, usage, status)

The same seed always gives byte-identical output.

CLI: python -m data.synthetic_data_generator --out experiment_data/synthetic
"""

import argparse
import csv
import json
import os
from typing import Dict, List, Optional, Tuple

import numpy as np

from config.config import Config

Batch = Tuple[List[str], List[int]]

DRIFT_SCHEDULE_20 = {
    4:  [{"type": "emerge", "n": 8}],
    6:  [{"type": "shift", "n": 4, "from": 1, "to": 0}, {"type": "shift", "n": 4, "from": 0, "to": -1}],
    8:  [{"type": "reverse", "n": 6, "tag": "R1"}],
    10: [{"type": "emerge", "n": 8}, {"type": "obsolete", "n": 8}],
    12: [{"type": "prior", "p": [0.45, 0.25, 0.30]}],
    14: [{"type": "reverse", "n": 6, "tag": "R2"}, {"type": "shift", "n": 4, "from": -1, "to": 0}],
    16: [{"type": "revert", "tag": "R1"}, {"type": "prior", "p": [0.30, 0.30, 0.40]}],
    18: [{"type": "emerge", "n": 10}, {"type": "obsolete", "n": 6}],
}


def scaled_schedule(num_steps: int) -> Dict[int, List[dict]]:
    """Map the 20-era schedule onto `num_steps` eras (era 1 stays drift-free)."""
    if num_steps == 20:
        return DRIFT_SCHEDULE_20
    out: Dict[int, List[dict]] = {}
    for era, events in DRIFT_SCHEDULE_20.items():
        e = min(num_steps, max(2, int(round(era * num_steps / 20))))
        out.setdefault(e, []).extend(events)
    # A revert must come strictly after its reversal; drop it otherwise.
    seen = set()
    for e in sorted(out):
        out[e] = [ev for ev in out[e] if not (ev["type"] == "revert" and ev["tag"] not in seen)]
        seen |= {ev["tag"] for ev in out[e] if ev["type"] == "reverse"}
    return out


def _make_words(rng, n, taken):
    cons = list("bcdfghjkmlnprstvwyz") + ["ch", "sh", "ng", "mb", "nd", "ny"]
    vows = list("aeiou")
    out = []
    while len(out) < n:
        w = "".join(rng.choice(cons) + rng.choice(vows) for _ in range(rng.integers(2, 4)))
        if w not in taken:
            taken.add(w)
            out.append(w)
    return out


class _Stream:
    N_SENT, N_TOPIC, N_FUNC, N_RESERVE = 30, 160, 30, 80
    P_NEGATION, P_NEUTRAL_PAIR, P_MIXED = 0.10, 0.30, 0.15

    def __init__(self, seed: int, num_classes: int, label_noise: float, schedule):
        self.rng = np.random.default_rng(seed)
        self.num_classes = num_classes
        self.noise = label_noise
        self.schedule = schedule
        r, taken = self.rng, set()
        self.function = _make_words(r, self.N_FUNC, taken)
        self.negators = _make_words(r, 3, taken)
        self.reserve = _make_words(r, self.N_RESERVE, taken)
        self.lex = {}
        for pol, n in [(1, self.N_SENT), (-1, self.N_SENT), (0, self.N_TOPIC)]:
            for w in _make_words(r, n, taken):
                self.lex[w] = {"pol": pol, "w": 1.0, "status": "active", "born": 1}
        self.base_pol = {w: d["pol"] for w, d in self.lex.items()}
        self.prior = np.array([0.30, 0.30, 0.40])
        if num_classes == 2:
            self.prior = np.array([0.45, 0.0, 0.55])
        self.reversals, self.events = {}, []

    def _pick(self, pol, n):
        cand = sorted(w for w, d in self.lex.items() if d["pol"] == pol and d["status"] == "active")
        return [str(w) for w in self.rng.choice(cand, size=min(n, len(cand)), replace=False)]

    def apply(self, era):
        for ev in self.schedule.get(era, []):
            t, rec = ev["type"], {"era": era, **ev}
            if t == "emerge":
                words = [self.reserve.pop() for _ in range(ev["n"])]
                pols = [1 if i % 2 == 0 else -1 for i in range(len(words))]
                for w, p in zip(words, pols):
                    self.lex[w] = {"pol": p, "w": 2.0, "status": "active", "born": era}
                rec["words"] = dict(zip(words, pols))
            elif t == "obsolete":
                words = self._pick(1, ev["n"] // 2) + self._pick(-1, ev["n"] - ev["n"] // 2)
                for w in words:
                    self.lex[w]["status"] = "fading"
                rec["words"] = words
            elif t == "shift":
                words = self._pick(ev["from"], ev["n"])
                for w in words:
                    self.lex[w]["pol"] = ev["to"]
                rec["words"] = words
            elif t == "reverse":
                words = self._pick(1, ev["n"] // 2) + self._pick(-1, ev["n"] - ev["n"] // 2)
                for w in words:
                    self.lex[w]["pol"] *= -1
                    self.lex[w]["w"] = 1.5
                self.reversals[ev["tag"]] = words
                rec["words"] = words
            elif t == "revert":
                words = self.reversals[ev["tag"]]
                for w in words:
                    self.lex[w]["pol"] *= -1
                rec["words"] = words
            elif t == "prior":
                p = np.array(ev["p"], dtype=float)
                if self.num_classes == 2:
                    p[1] = 0.0
                self.prior = p / p.sum()
            self.events.append(rec)

    def age(self):
        for d in self.lex.values():
            if d["status"] == "fading":
                d["w"] *= 0.35
                if d["w"] < 0.05:
                    d["status"] = "retired"
            elif d["w"] > 1.0:
                d["w"] = max(1.0, d["w"] * 0.85)

    def _draw(self, pol, k=1):
        cand = [(w, d["w"]) for w, d in self.lex.items() if d["pol"] == pol and d["status"] != "retired"]
        ws, p = zip(*cand)
        p = np.array(p) / sum(p)
        return [str(w) for w in self.rng.choice(ws, size=k, p=p)]

    def sample(self) -> Tuple[str, int, bool]:
        r = self.rng
        y = int(r.choice(3, p=self.prior))
        if y == 1:
            contribs = [] if r.random() >= self.P_NEUTRAL_PAIR else [1, -1]
        else:
            sign = 1 if y == 2 else -1
            n = int(r.choice([1, 2, 3], p=[0.5, 0.35, 0.15]))
            contribs = [sign] * n
            if n >= 2 and r.random() < self.P_MIXED:
                contribs[-1] = -sign
                contribs.append(sign)
        cues = []
        for c in contribs:
            if r.random() < self.P_NEGATION:
                cues.append([str(r.choice(self.negators)), self._draw(-c)[0]])
            else:
                cues.append([self._draw(c)[0]])
        n_fill = max(int(r.integers(6, 15)) - sum(len(c) for c in cues), 2)
        fill = [f if r.random() > 0.35 else str(r.choice(self.function)) for f in self._draw(0, n_fill)]
        chunks = [[f] for f in fill] + cues
        tokens = [t for i in r.permutation(len(chunks)) for t in chunks[i]]
        drifted = any(self.lex[c[-1]]["pol"] != self.base_pol.get(c[-1]) or self.lex[c[-1]]["born"] > 1
                      for c in cues)
        if r.random() < self.noise:
            y = int(r.choice([k for k in range(3) if k != y and self.prior[k] > 0]))
        if self.num_classes == 2:
            y = 0 if y == 0 else 1          # binary ids: 0 Negative, 1 Positive
        return " ".join(tokens), y, drifted


def generate_synthetic_data(
    num_time_steps: int = Config.NUM_TIME_STEPS,
    samples_per_step: int = Config.SAMPLES_PER_STEP,
    test_fraction: float = Config.TEST_FRACTION,
    num_classes: int = Config.NUM_LABELS,
    label_noise: float = Config.LABEL_NOISE,
    random_seed: int = Config.RANDOM_SEED,
    output_dir: Optional[str] = None,
) -> Tuple[List[Batch], List[Batch], Dict]:
    """Generate the stream. Returns (train_batches, test_batches, log)."""
    schedule = scaled_schedule(num_time_steps)
    s = _Stream(random_seed, num_classes, label_noise, schedule)
    n_test = int(round(samples_per_step * test_fraction))
    train, test, lex_rows, drift_share = [], [], [], {}
    for era in range(1, num_time_steps + 1):
        if era > 1:
            s.age()
        s.apply(era)
        rows = [s.sample() for _ in range(samples_per_step)]
        test.append(([t for t, _, _ in rows[:n_test]], [y for _, y, _ in rows[:n_test]]))
        train.append(([t for t, _, _ in rows[n_test:]], [y for _, y, _ in rows[n_test:]]))
        drift_share[era] = round(float(np.mean([d for _, _, d in rows])), 4)
        for w, d in s.lex.items():
            lex_rows.append([era, w, d["pol"], s.base_pol.get(w, ""), round(d["w"], 4), d["status"], d["born"]])

    log = {
        "num_steps": num_time_steps, "samples_per_step": samples_per_step,
        "test_fraction": test_fraction, "num_classes": num_classes, "label_noise": label_noise,
        "seed": random_seed, "labels": Config.LABELS if num_classes == 3 else ["Negative", "Positive"],
        "function_words": s.function, "negators": s.negators,
        "events": s.events, "drift_affected_share": drift_share,
    }
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        for prefix, batches in [("batch", train), ("test", test)]:
            for t, (texts, labels) in enumerate(batches, start=1):
                with open(os.path.join(output_dir, f"{prefix}_{t:03d}.jsonl"), "w", encoding="utf-8") as f:
                    for text, label in zip(texts, labels):
                        f.write(json.dumps({"text": text, "label": label}) + "\n")
        with open(os.path.join(output_dir, "evolution_log.json"), "w", encoding="utf-8") as f:
            json.dump(log, f, indent=2, default=int)
        with open(os.path.join(output_dir, "lexicon.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["era", "word", "polarity", "base_polarity", "usage_weight", "status", "born"])
            w.writerows(lex_rows)
        print(f"Synthetic data saved to {output_dir}")
    return train, test, log


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join("experiment_data", "synthetic"))
    ap.add_argument("--steps", type=int, default=Config.NUM_TIME_STEPS)
    ap.add_argument("--per-step", type=int, default=Config.SAMPLES_PER_STEP)
    ap.add_argument("--classes", type=int, choices=[2, 3], default=Config.NUM_LABELS)
    ap.add_argument("--seed", type=int, default=Config.RANDOM_SEED)
    a = ap.parse_args()
    generate_synthetic_data(a.steps, a.per_step, num_classes=a.classes, random_seed=a.seed, output_dir=a.out)
