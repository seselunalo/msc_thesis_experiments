"""
Export the cleaned Sheng dataset to the runner's per-era JSONL files.

Input : sheng_clean.csv, made by Desktop/claude/clean_sheng_dataset.py
        (columns used: text, label, era_merged, flag_english)
Output: sheng_era_N.jsonl (train) and sheng_era_N_test.jsonl (held-out test),
        N = 1..5, for 2021-2022, 2023, 2024, 2025 and 2026, plus metadata.json.

Each era is split into train and test, stratified by label, with a fixed seed.

Usage (from the project root):
    python -m data.export_sheng --csv sheng_clean.csv
    python -m data.export_sheng --csv ~/sheng_clean.csv --storage-root $EXPERIMENT_ROOT
    python -m data.export_sheng --csv ... --drop-english --classes 2

By default it reads sheng_clean.csv from the storage root (v7; v6 used a
Windows desktop path) and writes to the runner's Sheng folder under the same
root (see config/paths.py).
"""

import argparse
import csv
import json
import os
import random
from collections import Counter, defaultdict

from config.config import Config
from config.paths import SHENG_DIR, STORAGE_ROOT

ERA_KEYS = ["E1_2021-2022", "E2_2023", "E3_2024", "E4_2025", "E5_2026"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--storage-root", default=None,
                    help=f"storage root (default: $EXPERIMENT_ROOT, else ./experiment_data). Now: {STORAGE_ROOT}")
    ap.add_argument("--csv", default=os.path.join(STORAGE_ROOT, "sheng_clean.csv"),
                    help="the cleaned Sheng CSV (default: sheng_clean.csv in the storage root)")
    ap.add_argument("--out", default=SHENG_DIR, help="defaults to the runner's Sheng folder")
    ap.add_argument("--test-fraction", type=float, default=Config.TEST_FRACTION)
    ap.add_argument("--classes", type=int, choices=[2, 3], default=Config.NUM_LABELS)
    ap.add_argument("--drop-english", action="store_true", help="leave out rows flagged as plain English")
    ap.add_argument("--seed", type=int, default=Config.RANDOM_SEED)
    a = ap.parse_args()
    if not os.path.exists(a.csv):
        ap.error(f"CSV not found: {a.csv}. Pass --csv PATH.")

    labels = Config.LABELS if a.classes == 3 else ["Negative", "Positive"]
    label_id = {name: i for i, name in enumerate(labels)}
    rows = defaultdict(lambda: defaultdict(list))   # era -> label -> [text]
    with open(a.csv, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if a.drop_english and r.get("flag_english") == "True":
                continue
            if r["label"] not in label_id:            # e.g. Neutral when classes == 2
                continue
            rows[r["era_merged"]][label_id[r["label"]]].append(r["text"])

    os.makedirs(a.out, exist_ok=True)
    rng = random.Random(a.seed)
    meta = {"source": a.csv, "classes": a.classes, "labels": labels, "test_fraction": a.test_fraction,
            "seed": a.seed, "drop_english": a.drop_english, "eras": {}}
    for n, key in enumerate(ERA_KEYS, start=1):
        train, test = [], []
        for y, texts in sorted(rows[key].items()):
            texts = texts[:]
            rng.shuffle(texts)
            k = max(1, int(round(len(texts) * a.test_fraction)))
            test += [(t, y) for t in texts[:k]]
            train += [(t, y) for t in texts[k:]]
        rng.shuffle(train)
        rng.shuffle(test)
        for suffix, items in [("", train), ("_test", test)]:
            with open(os.path.join(a.out, f"sheng_era_{n}{suffix}.jsonl"), "w", encoding="utf-8") as f:
                for t, y in items:
                    f.write(json.dumps({"text": t, "label": y}, ensure_ascii=False) + "\n")
        meta["eras"][n] = {"name": key, "train": len(train), "test": len(test),
                           "train_labels": dict(Counter(labels[y] for _, y in train)),
                           "test_labels": dict(Counter(labels[y] for _, y in test))}
        print(f"era {n} ({key}): train {len(train)}, test {len(test)}")
    with open(os.path.join(a.out, "metadata.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    print(f"Written to {a.out}")


if __name__ == "__main__":
    main()
