"""
Baseline 3: Periodic retraining. Every `retrain_interval` eras the model is
retrained from the pre-trained weights on all data seen so far. Between
retrains it is not updated, so before the first retrain its classification
head is untrained (chance-level predictions).

Config.FULL_FT_MODE decides what each retrain trains: all weights ("full"),
or a fresh LoRA adapter ("lora", which fits a 16 GB T4). See baseline_naive_ft.py.

v5: retraining is mini-batched (v4 put all accumulated data through one
forward pass), and the old model is freed before the new one is loaded.
"""

import gc
import time
from typing import Optional

import torch

from config.config import Config
from models.base_model import BaseContinualModel


class BaselinePeriodic(BaseContinualModel):
    def __init__(self, retrain_interval: int = Config.PERIODIC_RETRAIN_INTERVAL,
                 epochs_per_retrain: int = Config.PERIODIC_EPOCHS, mode: Optional[str] = None,
                 device: str = Config.DEVICE, seed: int = Config.RANDOM_SEED):
        super().__init__(device=device, seed=seed)
        self.mode = mode or self.resolve_ft_mode()
        self.retrain_interval = retrain_interval
        self.epochs_per_retrain = epochs_per_retrain
        self.step_counter = 0
        self.texts, self.labels = [], []
        # Wrap the initial model the same way a retrain will, to count the
        # parameters each retrain updates. (A fresh LoRA adapter does not change
        # predictions, so the untrained starting point stays the same.)
        self.model, _ = self._make_adaptable(self.model, self.mode)
        self.n_trainable = self.get_total_trainable()
        print(f"Periodic mode: {self.mode}")

    def _retrain(self) -> float:
        self.model = None
        self.base_model = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        model, lr = self._make_adaptable(self._load_base_model(), self.mode)
        opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                                lr=lr, weight_decay=Config.WEIGHT_DECAY)
        loss = self._fit(model, opt, self.texts, self.labels, self.epochs_per_retrain)
        del opt
        self.model = self.base_model = model
        return loss

    def train_step(self, texts, labels):
        start = time.time()
        self.texts.extend(texts)
        self.labels.extend(labels)
        self.step_counter += 1
        loss = None               # no training between retrains (v5 reported 0.0 here)
        if self.step_counter % self.retrain_interval == 0:
            loss = self._retrain()
        return loss, time.time() - start

    def get_total_trainable(self) -> int:
        return sum(p.numel() for p in self.model.parameters() if p.requires_grad)

    def get_trainable_parameters(self) -> int:
        return self.n_trainable
