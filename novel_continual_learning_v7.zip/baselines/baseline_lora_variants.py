"""
LoRA-variant baselines (v6). Each one follows the Naive FT protocol: train on
each era in turn, EPOCHS_PER_ERA epochs of mini-batches, and no replay buffer.
Only the adapter changes, so against Naive FT (LoRA mode) they show what the
adapter variant alone does, and against Novel whether a better adapter can
replace replay.

    DoRA    Weight-Decomposed Low-Rank Adaptation (Liu et al., ICML 2024).
            Learns a magnitude vector plus a LoRA update of the direction.
            PEFT: LoraConfig(use_dora=True). The strongest general-purpose LoRA
            variant in PEFT; about 1.3-2x slower than LoRA per step.
    LoRA+   LoRA with a larger learning rate for B than for A (Hayou et al.,
            ICML 2024), ratio LORAPLUS_LR_RATIO = 16. Same parameters and
            memory as LoRA; only the optimiser changes. Tests whether faster
            adaptation to new eras helps or causes more forgetting.
    O-LoRA  Orthogonal subspace LoRA for continual learning (Wang et al.,
            Findings of EMNLP 2023). Each era trains a fresh LoRA adapter while
            an orthogonality penalty
                lambda * sum_modules || A_new @ A_old^T ||_F^2  (|.| = sum of |x|^2)
            keeps its A matrix (its input subspace) orthogonal to those of all
            earlier eras. Earlier adapters are frozen; we merge them into the
            base weights, which gives the same forward pass as keeping them
            as separate frozen adapters and uses no extra memory. Replay-free,
            continual-learning-specific: the closest published competitor to
            Novel. The classification head is shared and trained every era,
            as in the other baselines (the paper uses a generative LM with no
            head), so head drift can still cause forgetting.

All three use Novel's LoRA settings (r, alpha, dropout, target modules,
learning rate), so the comparison is like for like.
"""

import time
from typing import List

import torch
from peft import LoraConfig, TaskType, get_peft_model

from config.config import Config
from models.base_model import BaseContinualModel

VARIANTS = ("dora", "loraplus", "olora")


class BaselineLoRAVariant(BaseContinualModel):
    def __init__(self, variant: str, epochs_per_era: int = Config.EPOCHS_PER_ERA,
                 device: str = Config.DEVICE, seed: int = Config.RANDOM_SEED):
        assert variant in VARIANTS, variant
        super().__init__(device=device, seed=seed)
        self.variant = variant
        self.epochs_per_era = epochs_per_era
        self.past_A = {}                 # O-LoRA: module name -> stacked A of earlier eras (k x in)
        self.era = 0
        self.model = self._wrap(self.base_model)
        self.optimizer = self._make_optimizer()
        self.n_trainable = super().get_trainable_parameters()
        print(f"{self.name()}: {self.n_trainable:,} trainable parameters "
              f"({100 * self.n_trainable / self.get_total_parameters():.2f}%)")

    def name(self) -> str:
        return {"dora": "DoRA", "loraplus": "LoRA+", "olora": "O-LoRA"}[self.variant]

    def _wrap(self, model):
        cfg = LoraConfig(task_type=TaskType.SEQ_CLS, r=Config.LORA_R, lora_alpha=Config.LORA_ALPHA,
                         lora_dropout=Config.LORA_DROPOUT, target_modules=Config.LORA_TARGET_MODULES,
                         bias="none", use_dora=(self.variant == "dora"))
        return get_peft_model(model, cfg).to(self.device)

    def _make_optimizer(self):
        named = [(n, p) for n, p in self.model.named_parameters() if p.requires_grad]
        lr = Config.LEARNING_RATE
        if self.variant == "loraplus":
            groups = [{"params": [p for n, p in named if "lora_B" in n], "lr": lr * Config.LORAPLUS_LR_RATIO},
                      {"params": [p for n, p in named if "lora_B" not in n], "lr": lr}]
        else:
            groups = [{"params": [p for _, p in named], "lr": lr}]
        return torch.optim.AdamW(groups, weight_decay=Config.WEIGHT_DECAY)

    # ---------------------------------------------------------------- O-LoRA
    def _lora_A(self):
        """Current adapter's A matrices: {module name: (r x in) weight}."""
        out = {}
        for n, p in self.model.named_parameters():
            if "lora_A" in n and p.requires_grad:
                out[n.split(".lora_A")[0]] = p
        return out

    def _orth_loss(self, model):
        loss = 0.0
        for name, A in self._lora_A().items():
            old = self.past_A.get(name)
            if old is not None:
                loss = loss + (A @ old.t()).pow(2).sum()
        return Config.OLORA_LAMBDA * loss

    def _next_era_olora(self):
        """Freeze this era's adapter (merge it into W), remember its A, start a fresh one."""
        for name, A in self._lora_A().items():
            a = A.detach().clone()
            self.past_A[name] = a if name not in self.past_A else torch.cat([self.past_A[name], a], 0)
        # merge_and_unload folds LoRA into the weights and keeps the trained head.
        base = self.model.merge_and_unload()
        for p in base.parameters():
            p.requires_grad = False
        self.model = self.base_model = None
        self.optimizer = None
        self.model = self._wrap(base)
        self.base_model = base
        self.optimizer = self._make_optimizer()

    # ---------------------------------------------------------------- training
    def train_step(self, texts: List[str], labels: List[int]):
        start = time.time()
        if self.variant == "olora" and self.era > 0:
            self._next_era_olora()
        extra = self._orth_loss if (self.variant == "olora" and self.past_A) else None
        loss = self._fit(self.model, self.optimizer, texts, labels, self.epochs_per_era, extra_loss=extra)
        self.era += 1
        return loss, time.time() - start

    def get_trainable_parameters(self) -> int:
        # Per era. (O-LoRA trains a new adapter of this size each era.)
        return self.n_trainable

    def release(self):
        self.past_A = {}
        super().release()


class BaselineDoRA(BaselineLoRAVariant):
    def __init__(self, **kw):
        super().__init__("dora", **kw)


class BaselineLoRAPlus(BaselineLoRAVariant):
    def __init__(self, **kw):
        super().__init__("loraplus", **kw)


class BaselineOLoRA(BaselineLoRAVariant):
    def __init__(self, **kw):
        super().__init__("olora", **kw)
