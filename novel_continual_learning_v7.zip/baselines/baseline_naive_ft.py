"""
Baseline 2: Naive fine-tuning. The model is trained on each new era in turn,
with no replay, so this baseline shows catastrophic forgetting.

Config.FULL_FT_MODE decides what is trained:
  "full" - every weight (about 24 GB+ of GPU memory for the 1.5B model)
  "lora" - a LoRA adapter the same size as Novel's, but no replay (fits a 16 GB T4)
  "auto" - "full" on GPUs with 30 GB or more, otherwise "lora"
"""

import time
from typing import Optional

import torch

from config.config import Config
from models.base_model import BaseContinualModel


class BaselineNaiveFT(BaseContinualModel):
    def __init__(self, epochs_per_era: int = Config.EPOCHS_PER_ERA, mode: Optional[str] = None,
                 device: str = Config.DEVICE, seed: int = Config.RANDOM_SEED):
        super().__init__(device=device, seed=seed)
        self.mode = mode or self.resolve_ft_mode()
        self.model, lr = self._make_adaptable(self.model, self.mode)
        self.optimizer = torch.optim.AdamW([p for p in self.model.parameters() if p.requires_grad],
                                           lr=lr, weight_decay=Config.WEIGHT_DECAY)
        self.epochs_per_era = epochs_per_era
        print(f"Naive FT mode: {self.mode}")

    def train_step(self, texts, labels):
        start = time.time()
        loss = self._fit(self.model, self.optimizer, texts, labels, self.epochs_per_era)
        return loss, time.time() - start
