"""
Baseline 2: Naive fine-tuning. The model is trained on each new era in turn,
with no replay, so this baseline shows catastrophic forgetting.

Config.FULL_FT_MODE decides what is trained:
  "full" - every weight (about 24 GB+ of GPU memory for the 1.5B model)
  "lora" - a LoRA adapter the same size as Novel's, but no replay (fits a 16 GB T4)
  "auto" - "full" on GPUs with 30 GB or more, otherwise "lora"

v7.2: replay_mode lets the same full fine-tuning protocol run with Novel's
reservoir replay ("replay": "Naive FT + replay") or with the equal-exposure
control ("matched"), to test whether rehearsal helps full fine-tuning too or
only the low-rank adapter. The default ("none") is the original baseline.
"""

import time
from typing import Optional

import torch

from config.config import Config
from models.base_model import BaseContinualModel


class BaselineNaiveFT(BaseContinualModel):
    def __init__(self, epochs_per_era: int = Config.EPOCHS_PER_ERA, mode: Optional[str] = None,
                 replay_mode: str = "none", buffer_capacity: Optional[int] = None,
                 replay_batch_size: Optional[int] = None,
                 device: str = Config.DEVICE, seed: int = Config.RANDOM_SEED):
        super().__init__(device=device, seed=seed)
        self.mode = mode or self.resolve_ft_mode()
        self.model, lr = self._make_adaptable(self.model, self.mode)
        self.optimizer = torch.optim.AdamW([p for p in self.model.parameters() if p.requires_grad],
                                           lr=lr, weight_decay=Config.WEIGHT_DECAY)
        self.epochs_per_era = epochs_per_era
        cap = Config.BUFFER_CAPACITY if buffer_capacity is None and replay_mode != "none" else buffer_capacity
        self._setup_replay(replay_mode, cap,
                           Config.REPLAY_BATCH_SIZE if replay_batch_size is None else replay_batch_size, seed)
        print(f"Naive FT mode: {self.mode}, replay mode {self.replay_mode}")

    def train_step(self, texts, labels):
        start = time.time()
        loss = self._replay_fit(self.model, self.optimizer, texts, labels, self.epochs_per_era)
        return loss, time.time() - start
