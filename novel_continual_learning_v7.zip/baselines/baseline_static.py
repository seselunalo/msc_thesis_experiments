"""
Baseline 1: Static model, with no adaptation after the first era.

v5: the classification head is trained on the first era only (a linear probe on
the frozen W), then everything stays frozen. In v4 the head was never trained,
so Static was a random classifier rather than a "train once, never update"
baseline.
"""

import time

import torch

from config.config import Config
from models.base_model import BaseContinualModel


class BaselineStatic(BaseContinualModel):
    def __init__(self, learning_rate: float = Config.LEARNING_RATE,
                 epochs: int = Config.EPOCHS_PER_ERA, device: str = Config.DEVICE,
                 seed: int = Config.RANDOM_SEED):
        super().__init__(device=device, seed=seed)
        self.head = self._head_parameters(self.model)
        for p in self.head:
            p.requires_grad = True
        self.optimizer = torch.optim.AdamW(self.head, lr=learning_rate)
        self.epochs = epochs
        self.trained = False

    def train_step(self, texts, labels):
        if self.trained:
            return None, 0.0          # frozen after era 1: no training, no loss
        start = time.time()
        loss = self._fit(self.model, self.optimizer, texts, labels, self.epochs)
        for p in self.head:
            p.requires_grad = False
        self.trained = True
        return loss, time.time() - start

    def get_trainable_parameters(self) -> int:
        # Head size, reported even after it is frozen so the table is meaningful.
        return sum(p.numel() for p in self.head)
