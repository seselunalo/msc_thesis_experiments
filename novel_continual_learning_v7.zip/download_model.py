#!/usr/bin/env python3
"""
Download the base model (and tokenizer) into the Hugging Face cache, so jobs
can run on compute nodes without internet access (v7).

Run it once on a machine with internet, normally the Chui login node, with the
same HF_HOME the jobs will use (slurm/chui_env.sh sets it):

    source slurm/chui_env.sh
    python download_model.py                     # Config.BASE_MODEL_NAME (Qwen/Qwen2.5-1.5B)
    python download_model.py --model Qwen/Qwen2.5-0.5B

Then the jobs set HF_HUB_OFFLINE=1 and TRANSFORMERS_OFFLINE=1, and
transformers loads the model from the cache without contacting the Hub.
The script finishes by loading the tokenizer and config offline, to prove
the cache is complete.
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config.config import Config  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--model", default=Config.BASE_MODEL_NAME)
    ap.add_argument("--revision", default=None, help="a branch, tag or commit to pin (default: main)")
    a = ap.parse_args()

    if os.environ.get("HF_HUB_OFFLINE") == "1":
        sys.exit("HF_HUB_OFFLINE=1 is set; unset it to download (it is set only inside the jobs).")
    from huggingface_hub import snapshot_download
    print(f"HF cache: {os.environ.get('HF_HOME', '~/.cache/huggingface (HF_HOME not set)')}")
    path = snapshot_download(a.model, revision=a.revision,
                             allow_patterns=["*.json", "*.safetensors", "*.txt", "*.model", "*.py",
                                             "tokenizer*", "merges.txt", "vocab*"])
    print(f"Downloaded {a.model} to {path}")

    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    from transformers import AutoConfig, AutoTokenizer
    AutoTokenizer.from_pretrained(a.model, revision=a.revision)
    cfg = AutoConfig.from_pretrained(a.model, revision=a.revision)
    print(f"Offline load OK: {cfg.model_type}, {cfg.num_hidden_layers} layers")


if __name__ == "__main__":
    main()
