"""
Configuration parameters for the novel continual learning algorithm (v5).

v5 changes from v4:
- Three-class labels (0 Negative, 1 Neutral, 2 Positive).
- Mini-batched training with a fixed number of epochs per era (v4 took one
  gradient step per era on the whole batch).
- Replay is mixed into every mini-batch instead of the whole buffer at once.
- Held-out test split per era; the Sheng stream has 5 merged eras.
"""

import torch


class Config:
    # Model Configuration
    BASE_MODEL_NAME = "Qwen/Qwen2.5-1.5B"
    LABELS = ["Negative", "Neutral", "Positive"]   # index = class id
    NUM_LABELS = 3
    MAX_LENGTH = 128
    BATCH_SIZE = 16          # new samples per mini-batch
    EVAL_BATCH_SIZE = 64

    # LoRA Configuration
    LORA_R = 8
    LORA_ALPHA = 16
    LORA_DROPOUT = 0.1
    LORA_TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj"]

    # Memory Buffer Configuration
    BUFFER_CAPACITY = 1000
    REPLAY_BATCH_SIZE = 16   # buffer samples added to each mini-batch

    # Training Configuration
    LEARNING_RATE = 2e-4           # LoRA adapters and classification head
    FULL_FT_LEARNING_RATE = 2e-5   # Naive FT and Periodic (all weights)
    WEIGHT_DECAY = 0.01
    EPOCHS_PER_ERA = 2
    MAX_GRAD_NORM = 1.0

    # Synthetic Data Configuration
    NUM_TIME_STEPS = 10      # v7.1: 10 eras (was 20); the drift schedule is rescaled, all events kept
    SAMPLES_PER_STEP = 1000
    TEST_FRACTION = 0.2      # per era, held out for evaluation
    LABEL_NOISE = 0.03
    RANDOM_SEED = 42

    # Sheng Data Configuration (merged eras: 2021-22, 2023, 2024, 2025, 2026)
    NUM_SHENG_ERAS = 5
    SHENG_ERA_NAMES = ["2021-2022", "2023", "2024", "2025", "2026"]

    # How Naive FT and Periodic adapt the model:
    #   "full" - every weight is trained (needs roughly 24 GB+ GPU memory, e.g. A100 / L4)
    #   "lora" - a fresh LoRA adapter of the same size as Novel's, but no replay
    #            buffer (fits a 16 GB T4). Report which mode you used in the thesis.
    #   "auto" - "full" if the GPU has 30 GB or more, otherwise "lora".
    FULL_FT_MODE = "auto"
    GRADIENT_CHECKPOINTING = True   # saves activation memory in full mode

    # Periodic baseline
    PERIODIC_RETRAIN_INTERVAL = 3
    PERIODIC_EPOCHS = 2

    # LoRA-variant baselines (v6)
    LORAPLUS_LR_RATIO = 16      # LoRA+: lr(B) = 16 x lr(A), the paper's recommended default
    # v7.1: LoRA+'s A learning rate. v7 used LEARNING_RATE (2e-4), so B trained at
    # 3.2e-3 and LoRA+ collapsed on the synthetic stream in every seed (train loss
    # stuck at ln 3 = 1.099, i.e. uniform predictions; AA 0.30-0.38). 5e-5 gives
    # B 8e-4, the setting of PEFT's LoRA+ example (lr=5e-5, ratio 16). The
    # classification head keeps LEARNING_RATE, as in every other method.
    LORAPLUS_LR = 5e-5
    OLORA_LAMBDA = 0.5          # O-LoRA: weight of the orthogonality penalty (paper: lambda_1 = 0.5)

    # Evaluation Configuration
    EVAL_EVERY = 1
    NUM_RUNS = 5

    # Device Configuration
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
