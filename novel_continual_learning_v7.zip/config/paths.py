"""
Where experiment data, logs, checkpoints and results are stored (v7). Shared by
run_experiment.py, data/export_sheng.py and download_model.py.

The storage root is chosen in this order:
    1. --storage-root PATH on the command line (any of the scripts above)
    2. the EXPERIMENT_ROOT environment variable (the SLURM scripts set this)
    3. ./experiment_data in the current directory

v7 no longer detects Google Colab, Google Drive or Lightning AI. To run v7 on
Colab, pass --storage-root /content/drive/MyDrive/thesis_experiments.

--storage-root is read here, at import time, because every path below is a
module-level constant that the other modules import. The scripts also list it
in their own --help.

Layout under the root:
    novel_continual_learning/data/synthetic   synthetic stream (generated once)
    novel_continual_learning/data/sheng       Sheng eras (data/export_sheng.py)
    novel_continual_learning/experiments      logs, results, summaries
    novel_continual_learning/checkpoints      one file per finished run (--resume)
"""

import os
import sys


def _storage_root_from_argv(argv):
    for i, a in enumerate(argv):
        if a == "--storage-root" and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--storage-root="):
            return a.split("=", 1)[1]
    return None


def get_storage_root():
    root = _storage_root_from_argv(sys.argv[1:]) or os.environ.get("EXPERIMENT_ROOT")
    if not root:
        root = os.path.join(os.getcwd(), "experiment_data")
    return os.path.abspath(os.path.expanduser(os.path.expandvars(root)))


STORAGE_ROOT = get_storage_root()
os.environ["EXPERIMENT_ROOT"] = STORAGE_ROOT          # child processes see the same root
PROJECT_DIR = os.path.join(STORAGE_ROOT, "novel_continual_learning")
DATA_DIR = os.path.join(PROJECT_DIR, "data")
SYNTHETIC_DIR = os.path.join(DATA_DIR, "synthetic")
SHENG_DIR = os.path.join(DATA_DIR, "sheng")
LOGS_DIR = os.path.join(PROJECT_DIR, "experiments")
CHECKPOINT_DIR = os.path.join(PROJECT_DIR, "checkpoints")
