#!/usr/bin/env python3
"""
replay_study_report.py (v7.2): tables for the supervisor's replay study, built
from every finished run on disk. It trains nothing.

    python tools/replay_study_report.py                       # 10-era runs (the default)
    python tools/replay_study_report.py --eras 20             # 20-era runs instead; --eras 0 = any
    python tools/replay_study_report.py --storage-root ~/localscratch/thesis_v7

It reads checkpoints/v7_*/ (one store per setting, e.g. one per buffer
capacity or LoRA rank) and writes logs/replay_study_<time>.md plus four CSV files:

  1. Update method x replay arm (at the default capacity, 1000):
     {LoRA adapter (Novel), full fine-tuning (Naive FT)} x
     {replay, no replay, no replay at equal exposure}. Mean +- std over seeds,
     with optimizer updates, examples and tokens per arm, and paired t-tests
     (Holm-corrected within each dataset): replay vs no replay, replay vs
     matched, and whether replay helps LoRA more than full fine-tuning
     (difference of the two replay gains, paired by seed).
  2. Buffer capacity sweep: every capacity found on disk (64, 256, 1000, all)
     for Novel and Naive FT + replay, with final occupancy and how many past
     eras the buffer still holds.
  3. LoRA rank ablation: Novel at r = 4, 8, 16 (alpha = 2r, buffer 1000),
     with paired t-tests against r = 8 (Holm-corrected).
  4. Era coverage: per run and era, the buffer occupancy, the samples it holds
     from each past era, and how many replayed samples came from each era
     (replay_era_coverage.csv; one row per run, era and source era).
"""

import argparse
import csv
import glob
import json
import math
import os
import sys
from datetime import datetime

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.paths import CHECKPOINT_DIR, LOGS_DIR  # noqa: E402

try:
    from scipy import stats as _st      # installed with scikit-learn
except Exception:                        # noqa: BLE001
    _st = None

METRICS = ["AA", "AF", "FWT", "BWT", "LA", "Macro-F1"]
EXPOSURE = ["optimizer_updates", "examples_processed", "replay_examples", "resampled_examples",
            "tokens_processed"]
DESIGN = [("LoRA adapter", "Novel", "replay"), ("LoRA adapter", "Novel (no replay)", "no replay"),
          ("LoRA adapter", "Novel (matched)", "no replay, equal exposure"),
          ("Full fine-tuning", "Naive FT + replay", "replay"), ("Full fine-tuning", "Naive FT", "no replay"),
          ("Full fine-tuning", "Naive FT (matched)", "no replay, equal exposure")]
REPLAY_MODELS = ["Novel", "Naive FT + replay"]
SETTING_KEYS = ["quick", "model", "data_seed", "ft_mode", "synthetic_eras", "replay_batch"]
DEFAULT_R = 8


def load_stores(eras=None, quick=False):
    """-> {setting tuple: {(lora_r, capacity): {(dataset, model): {seed: result}}}}"""
    out = {}
    for d in sorted(glob.glob(os.path.join(CHECKPOINT_DIR, "v7_*"))):
        try:
            with open(os.path.join(d, "run_key.json"), encoding="utf-8") as f:
                key = json.load(f)
        except (OSError, ValueError):
            continue
        if key.get("version") not in ("v7.1",) and not key.get("version", "").startswith("v7.2"):
            continue                       # v7 runs have no exposure logs
        if bool(key.get("quick")) != quick or (eras and key.get("synthetic_eras") != eras):
            continue
        setting = tuple((k, key.get(k)) for k in SETTING_KEYS)
        cap = (key.get("lora_r", DEFAULT_R), key.get("buffer_capacity"))
        for p in glob.glob(os.path.join(d, "seed*", "*", "*.json")):
            try:
                with open(p, encoding="utf-8") as f:
                    r = json.load(f)
            except (OSError, ValueError):
                print(f"⚠️ unreadable {p}")
                continue
            out.setdefault(setting, {}).setdefault(cap, {}).setdefault(
                (r["dataset"], r["model"]), {})[int(r["seed"])] = r["result"]
    return out


def ms(values, fmt="{:.4f}"):
    v = np.array([x for x in values if x is not None and not (isinstance(x, float) and math.isnan(x))], float)
    if len(v) == 0:
        return "n/a"
    sd = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    return (fmt + " ± " + fmt).format(float(np.mean(v)), sd)


def paired(a, b):
    """a, b: {seed: value}. -> (mean diff, p, n) over common seeds."""
    seeds = sorted(set(a) & set(b))
    d = np.array([a[s] - b[s] for s in seeds], float)
    if len(d) < 2:
        return (float(d.mean()) if len(d) else float("nan")), float("nan"), len(d)
    if _st is None or np.allclose(d, d[0]):
        return float(d.mean()), float("nan"), len(d)
    return float(d.mean()), float(_st.ttest_rel([a[s] for s in seeds], [b[s] for s in seeds]).pvalue), len(d)


def holm(ps):
    idx = [i for i, p in enumerate(ps) if not math.isnan(p)]
    order = sorted(idx, key=lambda i: ps[i])
    out, run = [float("nan")] * len(ps), 0.0
    for rank, i in enumerate(order):
        run = max(run, min(1.0, (len(order) - rank) * ps[i]))
        out[i] = run
    return out


def fmt_p(p):
    return "n/a" if math.isnan(p) else ("< 0.001" if p < 0.001 else f"{p:.3f}")


def design_section(runs, lines, csv_rows, setting_name):
    datasets = sorted({ds for ds, _ in runs})
    for ds in datasets:
        lines.append(f"\n### {ds.capitalize()}: update method x replay (buffer 1000) {setting_name}\n")
        lines.append("| Update | Arm | Model | n | " + " | ".join(METRICS) +
                     " | Optimizer updates | Examples | Replayed | Resampled | Tokens |")
        lines.append("|---|---|---|---|" + "---|" * (len(METRICS) + 5))
        for upd, model, arm in DESIGN:
            r = runs.get((ds, model))
            if not r:
                lines.append(f"| {upd} | {arm} | {model} | 0 | " + " | ".join(["not run"] * (len(METRICS) + 5)) + " |")
                continue
            cells = [ms([x.get(m) for x in r.values()]) for m in METRICS]
            cells += [ms([x.get(k) for x in r.values()], "{:,.0f}") for k in EXPOSURE]
            lines.append(f"| {upd} | {arm} | {model} | {len(r)} | " + " | ".join(cells) + " |")
            for seed, x in r.items():
                csv_rows.append({"setting": setting_name, "dataset": ds, "update": upd, "arm": arm, "model": model,
                                 "seed": seed, **{m: x.get(m) for m in METRICS}, **{k: x.get(k) for k in EXPOSURE}})

        # paired tests
        def col(model, metric):
            return {s: x.get(metric) for s, x in (runs.get((ds, model)) or {}).items() if x.get(metric) is not None}
        tests = []
        for metric in ("AA", "AF", "BWT", "Macro-F1"):
            for upd, rep, none, matched in (("LoRA", "Novel", "Novel (no replay)", "Novel (matched)"),
                                            ("Full FT", "Naive FT + replay", "Naive FT", "Naive FT (matched)")):
                tests.append((f"{upd}: replay − no replay", metric, *paired(col(rep, metric), col(none, metric))))
                tests.append((f"{upd}: replay − equal exposure", metric, *paired(col(rep, metric), col(matched, metric))))
            # interaction: is the replay gain larger with LoRA than with full FT?
            g_l = {s: v - col("Novel (matched)", metric).get(s, float("nan"))
                   for s, v in col("Novel", metric).items() if s in col("Novel (matched)", metric)}
            g_f = {s: v - col("Naive FT (matched)", metric).get(s, float("nan"))
                   for s, v in col("Naive FT + replay", metric).items() if s in col("Naive FT (matched)", metric)}
            tests.append(("Replay gain (vs equal exposure): LoRA − full FT", metric, *paired(g_l, g_f)))
        ph = holm([t[3] for t in tests])
        lines.append(f"\nPaired t-tests over seeds ({ds}); Holm-adjusted across the {len(tests)} tests below. "
                     "AF: lower is better, so a negative difference means replay forgets less.\n")
        lines.append("| Comparison | Metric | Mean difference | n | p | p (Holm) |")
        lines.append("|---|---|---|---|---|---|")
        for (name, metric, diff, p, n), padj in zip(tests, ph):
            if n == 0:
                continue
            lines.append(f"| {name} | {metric} | {diff:+.4f} | {n} | {fmt_p(p)} | {fmt_p(padj)} |")


def capacity_section(by_cap, lines, csv_rows, setting_name):
    caps = sorted(by_cap, key=lambda c: float("inf") if c == "all" else float(c))
    datasets = sorted({ds for c in caps for ds, _ in by_cap[c]})
    for ds in datasets:
        lines.append(f"\n### {ds.capitalize()}: buffer capacity (replay ratio fixed) {setting_name}\n")
        lines.append("| Model | Capacity | n | AA | AF | BWT | LA | Macro-F1 | Final occupancy | "
                     "Past eras still in buffer (final) | Smallest era share (final) | Replayed examples |")
        lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        for model in REPLAY_MODELS:
            for cap in caps:
                r = by_cap[cap].get((ds, model))
                if not r:
                    continue
                occ, rep_eras, share = [], [], []
                for x in r.values():
                    last = (x.get("era_log") or [{}])[-1]
                    if "buffer_occupancy" in last:
                        occ.append(last["buffer_occupancy"])
                        counts = last.get("buffer_era_counts", {})
                        rep_eras.append(f"{last['buffer_eras_represented']}/{last['eras_seen']}")
                        tot = sum(counts.values()) or 1
                        # share of the least represented era among all eras seen (0 if one is gone)
                        share.append(min([counts.get(str(e), 0) for e in range(last["eras_seen"])]) / tot)
                cells = [ms([x.get(m) for x in r.values()]) for m in ("AA", "AF", "BWT", "LA", "Macro-F1")]
                lines.append(f"| {model} | {cap} | {len(r)} | " + " | ".join(cells) +
                             f" | {ms(occ, '{:,.0f}')} | {', '.join(sorted(set(rep_eras))) or 'n/a'} | "
                             f"{ms(share, '{:.3f}')} | {ms([x.get('replay_examples') for x in r.values()], '{:,.0f}')} |")
                for seed, x in r.items():
                    for e in x.get("era_log") or []:
                        if "buffer_occupancy" not in e:
                            continue
                        base = {"setting": setting_name, "dataset": ds, "model": model, "capacity": cap,
                                "seed": seed, "era": e["era"], "occupancy": e["buffer_occupancy"],
                                "eras_represented": e["buffer_eras_represented"], "eras_seen": e["eras_seen"],
                                "optimizer_updates": e.get("optimizer_updates"),
                                "tokens_processed": e.get("tokens_processed")}
                        draws = e.get("replay_draws_by_era", {})
                        for src in range(e["eras_seen"]):
                            csv_rows.append({**base, "source_era": src,
                                             "in_buffer": e["buffer_era_counts"].get(str(src), 0),
                                             "replayed_during_era": draws.get(str(src), 0)})


def rank_section(by_r, lines, csv_rows, setting_name):
    """Novel at each LoRA rank found on disk (buffer 1000), paired against r = 8."""
    ranks = sorted(by_r)
    datasets = sorted({ds for r in ranks for ds, m in by_r[r] if m == "Novel"})
    for ds in datasets:
        lines.append(f"\n### {ds.capitalize()}: LoRA rank (Novel, alpha = 2r, buffer 1000) {setting_name}\n")
        lines.append("| Rank r | n | " + " | ".join(METRICS) + " | Trainable % | Run time (s) | Peak GPU (MB) |")
        lines.append("|---|---|" + "---|" * (len(METRICS) + 3))
        for r in ranks:
            runs = by_r[r].get((ds, "Novel"))
            if not runs:
                continue
            cells = [ms([x.get(m) for x in runs.values()]) for m in METRICS]
            cells += [ms([x.get("trainable_percentage") for x in runs.values()], "{:.3f}"),
                      ms([x.get("total_time_seconds") for x in runs.values()], "{:.1f}"),
                      ms([x.get("gpu_peak_allocated_mb") for x in runs.values()], "{:,.0f}")]
            lines.append(f"| {r} | {len(runs)} | " + " | ".join(cells) + " |")
            for seed, x in runs.items():
                csv_rows.append({"setting": setting_name, "dataset": ds, "lora_r": r, "seed": seed,
                                 **{m: x.get(m) for m in METRICS},
                                 "trainable_percentage": x.get("trainable_percentage"),
                                 "total_time_seconds": x.get("total_time_seconds")})
        base = by_r.get(DEFAULT_R, {}).get((ds, "Novel"))
        if not base:
            lines.append(f"\n(no r = {DEFAULT_R} runs to compare against)")
            continue
        tests = []
        for r in ranks:
            runs = by_r[r].get((ds, "Novel"))
            if r == DEFAULT_R or not runs:
                continue
            for metric in ("AA", "AF", "BWT", "Macro-F1"):
                a = {sd: x[metric] for sd, x in runs.items() if x.get(metric) is not None}
                b = {sd: x[metric] for sd, x in base.items() if x.get(metric) is not None}
                tests.append((f"r = {r} − r = {DEFAULT_R}", metric, *paired(a, b)))
        ph = holm([t[3] for t in tests])
        lines.append(f"\nPaired t-tests over seeds against r = {DEFAULT_R} ({ds}), Holm-adjusted across these tests.\n")
        lines.append("| Comparison | Metric | Mean difference | n | p | p (Holm) |")
        lines.append("|---|---|---|---|---|---|")
        for (name, metric, diff, p, n), padj in zip(tests, ph):
            if n:
                lines.append(f"| {name} | {metric} | {diff:+.4f} | {n} | {fmt_p(p)} | {fmt_p(padj)} |")


def write_csv(path, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--storage-root", default=None, help="same as for run_experiment.py")
    ap.add_argument("--eras", type=int, default=10,
                    help="only settings with this many synthetic eras (default 10; 0 = any)")
    ap.add_argument("--quick", action="store_true", help="report --quick runs instead of full ones")
    args = ap.parse_args()

    stores = load_stores(args.eras or None, args.quick)
    if not stores:
        sys.exit(f"No v7.1/v7.2 runs found under {CHECKPOINT_DIR}"
                 + (f" with {args.eras} eras" if args.eras else "") + ".")
    lines = [f"# Replay study and rank ablation ({datetime.now():%Y-%m-%d %H:%M})", "",
             "Mean ± std over seeds. Equal exposure = no replay, but each mini-batch is topped up with "
             "resampled current-era data so the arm takes the same optimizer updates on the same number "
             "of examples as its replay arm (tokens differ slightly with text length; see the Tokens column)."]
    design_rows, cap_rows, cov_rows, rank_rows = [], [], [], []
    for setting, by_rc in stores.items():
        s = dict(setting)
        by_cap = {c: runs for (r, c), runs in by_rc.items() if r == DEFAULT_R}
        by_r = {r: runs for (r, c), runs in by_rc.items() if c == 1000}
        name = (f"[{s['synthetic_eras']} synthetic eras, ft-mode {s['ft_mode']}, "
                f"replay {s['replay_batch']}/batch]")
        lines.append(f"\n## Setting {name}")
        if s["ft_mode"] != "full":
            lines.append(f"\n> Note: ft-mode is '{s['ft_mode']}', so the Naive FT arms may be LoRA, not full "
                         "fine-tuning (auto picks LoRA on GPUs under 30 GB and on CPU). Use --ft-mode full.")
        if 1000 in by_cap:
            design_section(by_cap[1000], lines, design_rows, name)
        else:
            lines.append("\n(no runs at buffer capacity 1000 for the update x replay table)")
        capacity_section(by_cap, lines, cov_rows, name)
        if len(by_r) > 1:
            rank_section(by_r, lines, rank_rows, name)
        for cap, runs in by_cap.items():
            for (ds, model), r in runs.items():
                if model in REPLAY_MODELS:
                    for seed, x in r.items():
                        cap_rows.append({"setting": name, "dataset": ds, "model": model, "capacity": cap,
                                         "seed": seed, **{m: x.get(m) for m in METRICS},
                                         **{k: x.get(k) for k in EXPOSURE}})
    os.makedirs(LOGS_DIR, exist_ok=True)
    prefix = os.path.join(LOGS_DIR, f"replay_study_{datetime.now():%Y%m%d_%H%M%S}")
    with open(prefix + ".md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    write_csv(prefix + "_design.csv", design_rows)
    write_csv(prefix + "_capacity.csv", cap_rows)
    write_csv(prefix + "_era_coverage.csv", cov_rows)
    write_csv(prefix + "_rank.csv", rank_rows)
    print("\n".join(lines))
    print(f"\n📄 {prefix}.md and _design.csv, _capacity.csv, _era_coverage.csv, _rank.csv")


if __name__ == "__main__":
    main()
