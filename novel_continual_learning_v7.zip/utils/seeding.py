"""
Seeding and GPU-memory helpers (v6).

set_all_seeds() is called right before each (seed, dataset, method) run, so a
run gives the same result whether it ran first in a session or after a
--resume. It seeds every RNG the code uses: Python `random`, NumPy, PyTorch
(CPU and all GPUs) and Transformers. The model's own random.Random and the
replay buffer's RNG are seeded from the same value in BaseContinualModel.

GPU runs are close to, but not always bit-for-bit, reproducible: some CUDA
kernels (e.g. atomics in backward passes) are non-deterministic. We set
cudnn.deterministic, which removes the largest source, but do not force
torch.use_deterministic_algorithms because several ops used by Qwen would
then raise errors.
"""

import gc
import os
import random

import numpy as np
import torch


def set_all_seeds(seed: int):
    os.environ["PYTHONHASHSEED"] = str(seed)     # inherited by any subprocess
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    try:
        from transformers import set_seed
        set_seed(seed)
    except Exception:
        pass


def free_gpu_memory() -> float:
    """Collect garbage and return cached CUDA blocks to the driver.
    Returns the MB still allocated afterwards (0 on CPU)."""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
        return torch.cuda.memory_allocated() / 1024 ** 2
    return 0.0
