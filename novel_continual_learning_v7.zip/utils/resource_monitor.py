"""
Resource monitor (v6): CPU, RAM and GPU usage for one run.

A background thread samples every `interval` seconds while a model trains and
is evaluated:
    cpu_process_percent  this Python process. 100 = one full core, so on a
                         2-core VM the maximum is 200 (on SLURM: --cpus-per-task x 100).
    cpu_system_percent   the whole machine, 0-100 over all cores.
    ram_rss_mb           resident memory of this process (CPU RAM).
    gpu_util_percent     GPU utilisation (needs pynvml / nvidia-ml-py; left
                         out if unavailable).
GPU memory comes from PyTorch's own counters (max_memory_allocated /
max_memory_reserved), which are exact peaks rather than samples.
"""

import os
import threading
import time
from typing import Dict

import psutil
import torch


class ResourceMonitor:
    def __init__(self, interval: float = 1.0):
        self.interval = interval
        self.proc = psutil.Process(os.getpid())
        self._stop = threading.Event()
        self._thread = None
        self.cpu_proc, self.cpu_sys, self.rss, self.gpu_util = [], [], [], []
        self.start_time = None

    def _sample(self):
        self.cpu_proc.append(self.proc.cpu_percent(None))
        self.cpu_sys.append(psutil.cpu_percent(None))
        self.rss.append(self.proc.memory_info().rss / 1024 ** 2)
        if torch.cuda.is_available():
            try:
                self.gpu_util.append(float(torch.cuda.utilization()))
            except Exception:
                pass

    def _run(self):
        while not self._stop.wait(self.interval):
            self._sample()

    def start(self):
        self.proc.cpu_percent(None)          # the first call only sets the baseline
        psutil.cpu_percent(None)
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
        self.start_time = time.time()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def stop(self) -> Dict[str, float]:
        """Stop sampling and return the usage summary. Safe to call twice."""
        if self._stop.is_set():
            return {}
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
        self._sample()                       # at least one sample, even for very short runs
        mean = lambda v: float(sum(v) / len(v)) if v else float("nan")  # noqa: E731
        out = {
            "wall_time_seconds": time.time() - self.start_time,
            "cpu_process_percent_mean": mean(self.cpu_proc),
            "cpu_process_percent_max": float(max(self.cpu_proc)) if self.cpu_proc else float("nan"),
            "cpu_system_percent_mean": mean(self.cpu_sys),
            "cpu_count": psutil.cpu_count(),
            "ram_peak_rss_mb": float(max(self.rss)) if self.rss else float("nan"),
            "ram_mean_rss_mb": mean(self.rss),
            "resource_samples": len(self.cpu_proc),
        }
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            out["gpu_peak_allocated_mb"] = torch.cuda.max_memory_allocated() / 1024 ** 2
            out["gpu_peak_reserved_mb"] = torch.cuda.max_memory_reserved() / 1024 ** 2
            if self.gpu_util:
                out["gpu_util_percent_mean"] = mean(self.gpu_util)
        else:
            out["gpu_peak_allocated_mb"] = out["gpu_peak_reserved_mb"] = 0.0
        return out
