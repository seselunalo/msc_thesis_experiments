"""
Utility functions for metric computation.
"""

import numpy as np
from typing import List, Dict


def compute_metrics(era_histories: Dict[int, List[float]]) -> Dict[str, float]:
    """
    Compute AA, AF, FWT, and BWT from era histories.
    """
    results = {}

    # Average Accuracy (AA)
    final_accs = []
    for era_idx, accs in era_histories.items():
        if accs:
            final_accs.append(accs[-1])
    results["AA"] = np.mean(final_accs) if final_accs else 0.0

    # Average Forgetting (AF)
    forgetting_values = []
    for era_idx, accs in era_histories.items():
        if len(accs) >= 2:
            max_acc = max(accs)
            final_acc = accs[-1]
            forgetting_values.append(max_acc - final_acc)
    results["AF"] = np.mean(forgetting_values) if forgetting_values else 0.0

    # Forward Transfer (FWT) - average accuracy on most recent era
    if era_histories:
        last_era = max(era_histories.keys())
        if era_histories[last_era]:
            results["FWT"] = np.mean(era_histories[last_era][-5:])
        else:
            results["FWT"] = 0.0
    else:
        results["FWT"] = 0.0

    # Backward Transfer (BWT) - change in accuracy on earlier eras
    bwt_values = []
    for era_idx, accs in era_histories.items():
        if len(accs) >= 2:
            bwt_values.append(accs[-1] - accs[0])
    results["BWT"] = np.mean(bwt_values) if bwt_values else 0.0

    return results
